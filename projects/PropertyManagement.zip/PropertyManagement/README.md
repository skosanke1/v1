Property Ledger Application - Easily Save investment data by Property address
Just launch App.xlsm to manage tenant and property data
Tenant Data included is not accurate, used as sample data

Login screen, home screen, and proprty pages have been included as UI pages
Add employee information in data.accdb file, then login after opening App.xlsm to manage 
properties.xlsx, add tenants, change property details, or add fees and payments to ledger