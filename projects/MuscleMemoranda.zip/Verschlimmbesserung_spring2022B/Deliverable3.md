## 1: Basic Information (needed before you start with your Sprint -- Sprint Planning)

**Topic you chose:** Gym Scheduling Software

**Sprint Number:** 3

**Scrum Master**: Steven

**Git Master**: Igor

### Sprint Planning (For Sprint 1-3)
Document your Sprint Planning here. Also check the kickoff document for more details on what needs to be done. This is just the documentation. 

**Sprint Goal:** Put all changes together to make sure it works flawlessly and get it to final working prototype. We will also again write 4 unit tests each. Add final functionality and ensure the UI is pleasant. 

**How many User Stories did you add to the Product Backlog:**  8

**How many User Stories did you add to this Sprint:** 10
> Answer the questions below about your Sprint Planning?

**Why did you add these US, why do you think you can get them done in the next Sprint?**

> Because we are confident in our programing abilities. These US are building on what we have built so far, so we are familiar already and know how things work. 

**Why do you think these fit well with your Sprint goal? (details)**

> They fit well because by the end of this Sprint we need a working software, as stated in our goal. 

**Do you have a rough idea what you need to do? (if the answer is no then please let me know on Slack)**

> Yes!

## 2: During the Sprint

### Meeting minutes of your Daily Scrums (3 per week, should not take longer than 10 minutes):

| Date  | Who did NOT attend  |Meeting notes (very brief)   | Burndown Info (on track, ahead behind is enough) | GitHub Actions info (does the master pass) | Additional Info  |
|---|---|---|---|--|--|
| 4/19/22 |  | Initial Zoom meeting | on track | N/A |  |
| 4/21/22 | Robert, Igor | Started working on tasks | on track | N/A |  |
| 4/23/22 | Robert, Igor | Complete US Tasks and create tests | on track | N/A |  |
| 4/26/22 | Igor | Debugging and finishing final tasks | behind | N/A |  |
| 4/28/22 | Robert, Igor, Sepher | Final touch ups and unit tests | behind | N/A |  |

## 3: After the Sprint

### Sprint Review
Answer as a team!

**Screen Cast link**: Your link

> Answer the following questions as a team. 

**What do you think is the value you created this Sprint?**

> We created plenty of value within more of the frontend aspects of the application, we spent much of our time during the early sprints working on the functional updates that allowed us to work mostly on design/frontend for this sprint.

**Do you think you worked enough and that you did what was expected of you?**

> Yes, our sprint goal was met and we feel as a team that we provided a much improved product compared to what was given at the beginning of the term. The product now has new features, no apparent bugs, a more aesthetically pleasing design, and overall more valuable functionality.

**Would you say you met the customers’ expectations? Why, why not?**

> Yes, the customer expectations consisted of fixing up the Memoranda software and transforming it into a simple, easy to use Gym software with new capabilities such as scheduling classes and accessing People pages. We accomplished all that while also eliminating apparent bugs. The software could be used in a gym and provide value to a company such as our customers'. 


### Sprint Retrospective

> Include your Sprint retrospective here and answer the following questions in an evidence based manner as a team (I do not want each of your individuals opinion here but the team perspective). By evidence-based manner it means I want a Yes or No on each of these questions, and for you to provide evidence for your answer. That is, don’t just say "Yes we did work at a consistent rate because we tried hard"; say "we worked at a consistent rate because here are the following tasks we completed per team member and the rate of commits in our Git logs."

**Did you meet your sprint goal?**

> Yes, we feel that we've met our sprint goal as a team. Our unit tests were completed and the product is considerably better than it was pre-sprint. 

**Did you complete all stories on your Spring Backlog?**

> Yes, all of the stories we created were completed this sprint. 

**If not, what went wrong?**

> N/A

**Did you work at a consistent rate of speed, or velocity? (Meaning did you work during the whole Sprint or did you start working when the deadline approached.)**

> Our rate of speed differed for each team member with individual schedules, however, overall we worked at a consistent rate rate of speed. Some members made a push later on in the sprint, but all changes were tested thoroughly. 

**Did you deliver business value?**

> In a business environment, we believe that our software would thrive and suffice as a strong competitive product. The value we provided consisted of new features as well as seamless integration of functionality with design.

**Did you follow the Scrum process (e.g. move Tasks correctly?, keep the Taiga board up to date? work consistently?)**

> Yes, each team member assigned tasks throughout the sprint and completed them accordingly while also following our outlined Git process. This allowed us to succeed as a team and not worry towards the end of the sprint. 

**How do you feel at this point? Get a pulse on the optimism of the team.**

> The team seems to be in high spirits regarding our progress and are very happy with the outcome of the product. Overall, the three sprints were very valuable and taught each team member many lessons that we'll take along with us in our own respective careers. The software itself also made many great improvements. 

### Contributions:

#### Team member **STEVEN**:

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer).**

> I believe I worked consistently this sprint and put enough work into this project.  I did what I could do to bring as much functionality into the product as I could, and helped others when it was possible.  There were some drawbacks and definitely time constraints sometimes, but in the end I completed what is required and am happy with my contribuions this over all of the sprints.  

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/625f0f6013d3a2bac7a5af8b271d4e947f7513d6 - Task 124- Add 'Book Class' button and and class full function
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/b166c82093f3f99159dfb4258ce1c461253537e9 - Task 117 - Add a list of students to class
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/c55c382fdf7d7d5bf6ee5068bb7f1985a89e1711 - Task 116 - Track Student bookings
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/c243eadf82923a6eaaec698fa50a0a8c3317995a - Task 130 - Configure gradle build file
 
 **GitHub links to your Pull Requests (up to 3 links)**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/31 - US110-full-class
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/31 - Refactor tests and update repository
 
 **GitHub links to your Unit Tests (up to 3 links)**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/9320130406a0fd735e86f5a78300e87c6de3709d - Tests for Event.java new added attributes

  **GitHub links to your Code Reviews (up to 3 links)**
    
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/38 - Reviewed US-62 added health functionality
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/41 - Reviewed unit tests
    
   
   JACE:

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/d87b8dd87235e99f8259c161a26e7d4e10258351 - Fixed title of Dialog
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/163a16f4c8c74e37823dd8368bc992e5735948bf - Adding new button and Backend for      action

  **GitHub links to your Pull Requests (up to 3 links):**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/36 - Adding Health Tips Button AND Functionality

   **GitHub links to your Unit Tests (up to 3 links):**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/49930985b25bed5432e22c7908b08bb7b3a9cd44 - Adding all 4 unit tests.

  **GitHub links to your Code Reviews (up to 3 links):**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/35#pullrequestreview-956601673 - Reviewing Haleigh's unit tests
    - link2


#### Team member **Haleigh**:

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer).**

> Yes, I made even more of an effort to work consistently this sprint, so I started working earlier than I have last sprints. I think
> managed a pretty good balance. Although the US I worked on this week were not as hard as last week, they added a lot of functionality.

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/33/commits/36ec160bdf1cfddf3b70a560cc4d7aaa6900b824 - Make People Editable
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/33/commits/326e2725063cf2290e2a94b1c976b8347ada7702 - More People Editing
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/32/commits/c1836f795db13e2bde89e08136c0afc12e632260 - Get rid of NPE from removing note
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/41/commits/98d29893b3be7bbbd8d4934b26d1e241ba896fb1 - User dropbox on Agenda
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/41/commits/60a94db179ea5a7a1bf4883d942a52bde67dde9a - Display table on Agenda
 
 **GitHub links to your Pull Requests (up to 3 links)**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/41 - US103 Pull Request
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/33 - US107 Pull Request
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/32 - US102 Pull Request
 
 **GitHub links to your Unit Tests (up to 3 links)**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/33/commits/0fcbf168b6f9b650336eaad77b5d06f5d4147a8b - For Editing People
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/41/commits/e1db7e999472f49c22a6ea0ca9f70b816a6b5fcd - For Agenda logic

  **GitHub links to your Code Reviews (up to 3 links)**
    
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/39 - Reviewed Unit Tests
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/43 - Reviewed Spotbugs check - checkstyle fixes


#### Team member **Robert*:

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer).**

> I was unable to work as consistently as I would have liked due to health reasons, but I did put in a good deal of work closer to the end when I was able.

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/47/commits/c39f1b9385bbb46216c850365b4f554a3e314644 - Task132
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/47/commits/f1361ce90fdbd52b1ffc2080438e4d45c0e49e88 - Task133
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/47/commits/f1361ce90fdbd52b1ffc2080438e4d45c0e49e88 - Task133
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/47/commits/e53b0efcc3bfbfbe1ac715062fd6c14da4ba0053 - Task134
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/XXX - XXX
 
 **GitHub links to your Pull Requests (up to 3 links)**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/47 - US105 pull request
 
 **GitHub links to your Unit Tests (up to 3 links)**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/47 - Tests for US105 (same as above)

  **GitHub links to your Code Reviews (up to 3 links)**
  
  Copy the section for each team member and then everyone adds their individual contributions. 
/////////////////////////////////////////////////////////////////////////////////////////////////////
#### Team member Igor Aleksic:

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer).**

> I feel that I worked as consitently as I could for this project. I added some unit tests, and reviewed a good amount of commits to be merged into dev. Due to finals and other final assignments with classes I got a later start than I would have hoped, but I still helped fix bugs and keep the system running as smooth as possible.

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :**

    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/d547a4a87f55ef7a0847c15cd5054ec8564e49c0 fix checkstyle up
    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/70659c65e1b48a16264b3354b729e5e8413ecf53 task table fixes
    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/c81bdc62059a8312cffd4da7b391deb44a7ff55b events checkstyle fixes
    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/e1e1c320d206c65cec8adfac278c058f2237ac96 bug fixes 
   https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/c4929f68197fc55429ff34e5a770a0ad248fe4f1 - checkstyle
   
 
 **GitHub links to your Pull Requests (up to 3 links)**

    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/81fba17cd1e15372d4b821bab49f0d60a2f36b3f checkstyle and spotbug into dev PR
    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/49 - merge check-spotbugs into dev
    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/50 PR to master 
    
    
 
 **GitHub links to your Unit Tests (up to 3 links)**

   https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/a712f86c4cc2118069956f4860269c3144af431f test for events class 
  **GitHub links to your Code Reviews (up to 3 links)**
    
    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/1ac192340dd75cdb67cf5a8b9357d9b6980f7fb1 - reviewed Robert
    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/81fba17cd1e15372d4b821bab49f0d60a2f36b3f - merge dev into master review
    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/31286c4e197e8fd54da19c00ec62e61d2241870d - merge review edit people

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    

## Below is just for you as a little reminder on what needs to be done
### Checklist for you to see if you are done with the current Sprint
- [ ] Form above is complete
- [ ] Your newest software is on the master branch on GitHub, it is tested and compiles/runs
- [ ] This document is in your master branch on GitHub
- [ ] Read the kickoff again to make sure you have all the details that I want
- [ ] User Stories that were not completed, were left in the Sprint and a copy created to move to the next Sprint
- [ ] Your Quality Policies are accurate and up to date
**Individual** Survey was submitted **individually**
- [X] Jace
- [ ] Sepehr
- [X] Robert
- [X] Steven
- [X] Igor
- [x] Haleigh


Copy the section for each team member and then everyone adds their individual contributions. 
/////////////////////////////////////////////////////////////////////////////////////////////////////
#### Team member **XXX**:

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer).**

> Yes I do.

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/XXX - Task XXX
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/XXX - XXX
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/XXX - XXX
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/XXX - XXX
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/XXX - XXX
 
 **GitHub links to your Pull Requests (up to 3 links)**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/XX - USXX-XXX pull request
 
 **GitHub links to your Unit Tests (up to 3 links)**

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/49930985b25bed5432e22c7908b08bb7b3a9cd44 - Tests for XXX

  **GitHub links to your Code Reviews (up to 3 links)**
    
    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/49930985b25bed5432e22c7908b08bb7b3a9cd44 - Reviewed US-XXX

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
