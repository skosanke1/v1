## 1: Basic Information (needed before you start with your Sprint -- Sprint Planning)

**Topic you chose:** Gym Management System

**Sprint Number:** 1

**Scrum Master**: Jace

**Git Master**: Robert

### Sprint Planning (For Sprint 1-3)

**Sprint Goal:** Our sprint goal for Sprint 1 is to complete each of the tasks assigned from Professor Mehlhase's Taiga board as well as the User Stories/Tasks we have created to better fit our program. Once completing these tasks, then we'll be able to start with a clean slate for Sprint 2 and Sprint 3 in the coming weeks.

**How many User Stories did you add to the Product Backlog:**  3


**How many User Stories did you add to this Sprint:** 2

> Answer the questions below about your Sprint Planning?

**Why did you add these US, why do you think you can get them done in the next Sprint?**

> We added these US's so that we can improve our UI to be ready for coming weeks.

**Why do you think these fit well with your Sprint goal? (details)**

> They will allow us to have a clean slate for Sprint 2 and further our development on larger tasks in the coming weeks

**Do you have a rough idea what you need to do? (if the answer is no then please let me know on Slack)**

> Yes



## 2: During the Sprint
> Fill out the Meeting minutes during your Sprint and keep track of things. Update your Quality policies when needed, as explained in the lectures and in the Quality Policy documents on Canvas. 
I would also advise you to already fill out the Contributions section (End of sprint) as you go, to create less work at the end.

### Meeting minutes of your Daily Scrums (3 per week, should not take longer than 10 minutes):
### Sprint Meeting 1
Date: 3/27/22 (Zoom)
Attendance: Everyone attended
Notes: We went into detail about how the sprint would look and went over Taiga scrum board.
Github info: All setup or individual repos.
### Sprint Meeting 2
Date: 3/30/22 (Slack)
Attendance: Everyone checked in
Notes: We all checked in with our progress on each task.
Github info: Igor, Steven, and Robert merged to our Dev branch
### Sprint Meeting 3
Date: 4/1/22 (Slack)
Attendance: Everyone checked in
Notes:We all checked in with our progress on each task.
Github info: No Dev merges, Jace's User Stories and Haleigh's User Stories were merged.
### Sprint Meeting 4
Date: 4/3/22 (Slack)
Attendance: Everyone checked in
Notes: We went over the end of the sprint and which tasks needed to still be addressed before merging to master.
Github info: Jace & Haleigh merged to our Dev branch.


## 3: After the Sprint

### Sprint Review
Answer as a team!

**Screen Cast link**: https://www.youtube.com/watch?v=GnNaiqorHG0

> Answer the following questions as a team. 

**What do you think is the value you created this Sprint?**

> As a team, we learned a lot about managing git branches while working with other members of a team. At times, some of us would be working on the same User Story and had to be great at communicating when things were getting merged and if we needed approvals/advice. We didn't have any merge conflicts this time around, but I'm sure we will in future sprints. This development of communication will help us in situations like that.

**Do you think you worked enough and that you did what was expected of you?**

> Yes. The team completed all of our tasks assigned in this sprint. The majority of our tasks were completed days in advance of the deadlines we set for ourselves, so I believe we are very happy with our work performance.

**Would you say you met the customers’ expectations? Why, why not?**

> Yes, most of our changes were UI related and made the application much more coherent as a gym program. Icons, images, headings, and text were all updated to match our mission as a team.


### Sprint Retrospective

**Did you meet your sprint goal?**

> Yes. Each task that we assigned to ourselves this sprint had been completed by the end of the sprint. Our overarching goal as a team for this sprint was to have a clean slate heading into Sprint 2. We have done that as our Scrum board is looking light (in a good way) as we'll need more tasks. We believe that through the work done with each other on Slack/Zoom throughout the week that this contributed to the sprint going so smoothly and will continue this trend going forward.

**Did you complete all stories on your Spring Backlog?**

> Yes. There were a few that got pushed to the last day of the sprint, but knowing how small these tasks were it was no issue. For the next sprints we'll want to get some of these tasks done earlier based on how large they will be, but we did manage to complete them all this time around.

**Did you work at a consistent rate of speed, or velocity? (Meaning did you work during the whole Sprint or did you start working when the deadline approached.)**

> As a team, we worked at a consistent rate of speed overall. The User Stories: US11, US12, US15 were all great examples of User Stories that team members began working on right away at the beginning of the sprint. US15 required work throughout the week because it had tasks assigned to multiple people within it.

Some tasks such as the "Search Button" task did not get worked on til much later in the sprint, but through communication with everyone on the team we were able to complete it. 

**Did you deliver business value?**

> Absolutely. Providing business value on our team consists of quality, following the process, and consistency. Everyone on the team has been amazing about checking in with their task-progress every other day, communicating about PRs, troubleshooting with other team members, and being dilligent about tasks being completed properly.

The business value here is really consistency and we are proud to have displayed this throughout the first sprint.

**Did you follow the Scrum process (e.g. move Tasks correctly?, keep the Taiga board up to date? work consistently?)**

> Yes, each person on the team would assign themselves a task, then move the task to "In Progress" once they began working on it. They would move the task to "Ready for Testing" once it was merged to the User Story, and finally "Complete" the task on the Scrum board once it was merged to the Dev branch. Once everything was merged to the Dev branch and "Complete", we merged to Master.

**Are there things the team thinks it can do better in the next Sprint? (not needed for last Sprint)**

> As a team, we could definitely prioritize the "effort points" for tasks better. This was something that was misunderstood by us at the beginning of the sprint and didn't get resolved until towards the end, we will work on that for Sprint 2 and assign those points at the beginning of the sprint.

**How do you feel at this point? Get a pulse on the optimism of the team.**

> The team feels great about our performance and everyone gets along really well. Sometimes it can be difficult working on group projects in an online format, but how we all work together has been very impressive and everyone is very happy with our progress on the Muscle Memoranda application.

### Contributions:

> In this section I want you to point me to your main contributions (each of you individually) for the current Sprint. Some of the below you will only need starting in later Sprints, I marked when they become important. 

Copy the section for each team member and then everyone adds their individual contributions. 

#### Team member Jace -- :

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer). 

  Yes, I believe that I contributed by completing my tasks on time, as well as creating a new logo for the application. Learning Git while simultaneously making changes to this codebase has included a lot of learning, but I feel I've been able to contribute nonetheless. 

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/dc4da26cf7f06436f6cdb3d808fdfc29ce50c8de - Updating title from Notes to be Gym Notes

    - https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/d3e8c9aed95e133848180cff9253ae12cc6816ea - Updating splash screen with new logo

    -https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/8af2b8b02f97b9e911c241fdd4123e362d008c16 - Add new logo to repo

#### Team member Sepehr -- :

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer). 

 I completed the tasks assigned to myself, and helped the team in different ways (participating in planning, providing ideas/feedbacks/approvals, etc). Unfortunately, I was not able to take on additional tasks due to personal circumastances and software issues.

  Example: 
  [Commit 1](https://github.com/amehlhase316/memoranda/commit/b949872433ae07f723bebe13c916064d03ef8882) - Updated DeliverableX.md table to include who did not attend meetings

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :

    - [Commit 1](https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/f7fcac14912d65613716e16e54f728d2a185c184) - Merged branch dev
    - [Commit 2](https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/32990b185d10f033866b6b5fc5c0e3eab48f82e1) - Made notes search button more visible. Updated left column icons to correspond with new panel names. 
 
#### Team member ROBERT -- :

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer). 

 Below I want links that I can click on to your commit or PullRequest with your work (not the branch you worked on). I also want a short description what this commit/PR is about (or test etc.)

  Example: 
  [Commit 1](https://github.com/amehlhase316/memoranda/commit/b949872433ae07f723bebe13c916064d03ef8882) - Updated DeliverableX.md table to include who did not attend meetings

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :

    - [Commit 1](https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/tree/US1-terminate)
    - [Commit 2](https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/tree/US24-left-column)
	- [Commit 3](https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/tree/US16-reverse-engineer)

  **GitHub links to your Pull Requests (up to 3 links) -- fill out starting Sprint 1:

    - [Pull Request 1](https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/4)
    - link2
  
#### Team member IGOR -- :

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer). 
	
	Yes I do. I was involved every step of the way and learned git and taiga along with the other team members. I found out why preference wasn't working and updated it accordingly, along with helping my team wherever I can. I put in the hours neccessary for the group, if not more, and did all tasks that I assigned myself.



 Below I want links that I can click on to your commit or PullRequest with your work (not the branch you worked on). I also want a short description what this commit/PR is about (or test etc.)

  Example: 
  [Commit 1](https://github.com/amehlhase316/memoranda/commit/b949872433ae07f723bebe13c916064d03ef8882) - Updated DeliverableX.md table to include who did not attend meetings

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :

    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/8775566ff6c9caf0f986342defeffaea2093831a -- removed the look and feel section
	
    https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/05d90af6f8400a0c918b0d443e22988182073a66 - merge into US in order to achive fast forward
	https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/df1e388ffeed5407937f670b856bebff69572441 - fixed preference

  **GitHub links to your Pull Requests (up to 3 links) -- fill out starting Sprint 1:

    - link1
    - link2

#### Team member Haleigh -- :

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer). 

	I completed all tasks that I assigned to myself, and definitely spent the 10 hour requirement on the project spread across different days. I always have "I'm not doing enough" mindset in group projects that propells me to do more than necessary, but this project it is hard to act on that feeling because you can't adjust how many tasks there are and don't want to take them all so that someone else suffers in participation.

 Below I want links that I can click on to your commit or PullRequest with your work (not the branch you worked on). I also want a short description what this commit/PR is about (or test etc.)

  Example: 
  [Commit 1](https://github.com/amehlhase316/memoranda/commit/b949872433ae07f723bebe13c916064d03ef8882) - Updated DeliverableX.md table to include who did not attend meetings

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :

    - [Commit 1] https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/a7d627e2bf4995d8bca3ed6450f2333d1a88a967
    - [Commit 2] https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/767a839823ae45c19bf9b3ee55363c0693f33b10
    - [Commit 3] https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/fe40a2716c1ea7a492e3961943b4a1d4fe0e4c2d
    - [Commit 4] https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/ce183607aaf0cfdec82432994f3fa6b454cb6773
    - [Commit 5] https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/4d29deb27b77ee8a31a14993d134d0c91b057885

  **GitHub links to your Pull Requests (up to 3 links) -- fill out starting Sprint 1:

    - None

#### Team member STEVEN -- :

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer). 
I believe that I worked consistently this Sprint and put enough work into this project.  I committed multiple times each week and 
tasks within multiple User Stories.


  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :

    [Commit 1] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/76fd54481de8f7345695c23f60306d50450508a9) - Fix non-english main page text
    [Commit 2] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/17ed0ed84083cca7f38159c962556c36f7e5a809) - Fix language issue in file popups
    [Commit 3] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/7f36b5924359d2c38386ffda33157ac6b7f7b07f) - Reformat 'About' Window
    [Commit 4] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/ee7436243123610f7cf9d70bc799c04c3e64f7ef) - Change 'Default project' to 'Room 1'
    [Commit 5] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/d35189824eff96fca8a3e4c5247e0a43483ade10) - Change app version, build names



## Below is just for you as a little reminder on what needs to be done
### Checklist for you to see if you are done with the current Sprint
- [X] Form above is complete
- [X] Your newest software is on the master branch on GitHub, it is tested and compiles/runs
- [X] This document is in your master branch on GitHub
- [X] Read the kickoff again to make sure you have all the details that I want
- [X] User Stories that were not completed, were left in the Sprint and a copy created to move to the next Sprint
- [X] Your Quality Policies are accurate and up to date
- [X] **Individual** Survey was submitted **individually** (create checkboxes below -- see Canvas to get link)
  - [X] JACE
  - [X] ROBERT
  - [X] HALEIGH
  - [X] SEPEHR
  - [X] STEVEN
  - [X] IGOR

#### For the next Sprint
  - [X] The original of this file was copied for the next Sprint (needed for all but last Sprint where you do not need to copy it anymore)
    - [X] Basic information (part 1) for next Sprint was included in this new Deliverable document 
  - [X] You added new User Stories to your Product Backlog, they are correctly written (needed after Sprint 1, 2)
  - [X] All User Stories have acceptance tests
  - [X] User Stories in your new Sprint Backlog have initial tasks which are in New column
  - [X] You know how to proceed (if not please reach out)

