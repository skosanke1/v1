**Muscle Memoranda** *by Verschlimmbersserung Spring 2022*
> Our group has created a gym scheduling software for use in Karate or other martial arts facilities.  It includes important functionality for scheduling classes and adding students and trainers to a people database.  There is flexibility within our software that allows many different types of gyms to be able to use this software as well, such as for a weightlifting gym.  People can be added into a database, where their information such as status, rank, and schedule are kept.  It is designed to be able to be used by anybody that uses the gym, including the owner, trainer, and students.   

**Our scheduling tool includes these key features**
* The Gym has private and public classes
* The Gym has only 4 rooms in which always one class can happen at a time
* Each class needs a trainer with an appropriate training rank
* trainers have a name, a training rank and a belt rank (this is their rank)
* the owner can assign him/herself to a class if s/he wants to teach it
* the owner can enter trainers into the system with their rank and training rank
 the trainer can setup possible private appointment times, these times can be booked
* by customers.
* Students and trainers can generate a random workout for workout inspiration
* the students can book private classes that are already setup and are not booked by
someone yet, or enroll in public classes.
* Students cannot sign up for a class twice, and cannot overbook a class
* Max class size is 20 people for public classes
* Max class size is 1 for private classes
* Trainers, owners and students can view their overall and their own schedule at any
time on the home page
* all users should be able to store their own notes on things in the tool which should
show up after they login
* trainers can set times when they are available to teach so the system will only assign
them to classes at these times
* Trainers can either teach classes or take classes
* Trainers can always teach all students below their training rank
* for advanced public classes only black2 training rank students can teach advanced
classes.
* Users can also receive training tips to improve their overall health

*Runs on Gradle 6.6.1 with Java.*  In order to run, clone repository into new folder, open repo in terminal, and type (in terminal):
*To build the application, and to see checkstyle and SpotBugs reports and to view the test report*
* 'gradle build'
*To see jacoco test coverage*
* 'gradle test jacocoTestReport'
*To run Muscle Memoranda*
* 'gradle run'
