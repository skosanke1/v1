package main.java.memoranda;

public interface TrainerNotificationListener {
    void beltRankChanged(People.BeltRank rank);
    void trainingRankChanged(People.BeltRank rank);
    void scheduleChanged();
}
