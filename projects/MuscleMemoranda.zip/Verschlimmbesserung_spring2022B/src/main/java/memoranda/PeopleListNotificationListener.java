package main.java.memoranda;

public interface PeopleListNotificationListener {
    void personAdded(People person);
    void personRemoved(People person);
}
