package main.java.memoranda;

public class TrainerSchedule {
    private String trainerName;
    private String fromTime;
    private String toTime;

    public TrainerSchedule(String trainerName, String fromTime, String toTime) {
        this.trainerName = trainerName;
        this.fromTime = fromTime;
        this.toTime = toTime;
    }

    public String getTrainerName() {
        return trainerName;
    }

    public String getFromTime() {
        return fromTime;
    }

    public String getToTime() {
        return toTime;
    }

    @Override
    public String toString() {
        return trainerName + "," + fromTime + "," + toTime;
    }


    public static TrainerSchedule fromString(String s) {
        if (s.length() < 2) {
            return null;
        }

        String[] scheduleStr = s.split(",", 0);
        String trainerName = scheduleStr[0];
        String from = scheduleStr[1];
        String to = scheduleStr[2];
        return new TrainerSchedule(trainerName, from, to);
    }
}
