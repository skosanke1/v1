package main.java.memoranda;


import java.util.ArrayList;
import java.util.List;

public class Student extends People {
	private List<TrainerSchedule> schedules;

	public Student(String name, BeltRank beltRank) {
		super(name, beltRank, Title.STUDENT);
		schedules = new ArrayList<>();
	}

	public void addSchedule(TrainerSchedule schedule) {
		schedules.add(schedule);
	}

	public void removeSchedule(TrainerSchedule schedule) {
		schedules.add(schedule);
	}

	public List<TrainerSchedule> getSchedules() {
		return schedules;
	}
}
