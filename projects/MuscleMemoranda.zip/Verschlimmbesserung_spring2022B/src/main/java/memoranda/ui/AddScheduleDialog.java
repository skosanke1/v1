package main.java.memoranda.ui;

import main.java.memoranda.CurrentProject;
import main.java.memoranda.People;
import main.java.memoranda.Trainer;
import main.java.memoranda.util.Local;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

public class AddScheduleDialog extends JDialog {
    JPanel dialogTitlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel header = new JLabel();
    JPanel areaPanel = new JPanel(new GridBagLayout());
    GridBagConstraints gridBagConstrains;

    // Labels for Text Fields
    JLabel trainerLabel = new JLabel();
    JLabel startTimeLabel = new JLabel();
    JLabel endTimeLabel = new JLabel();

    // Combo Box Options
    String[] daysOfTheWeex = new String[] { "Monday", "Tuesday", "Wednesday",
    "Thursday", "Friday", "Saturday", "Sunday" };

    // Combo Boxes
    JComboBox<String> trainerOptionsBox;
    JComboBox<String> dayOfTheWeekOptionsBox = new JComboBox<>(daysOfTheWeex);

    // Spinners
    public JSpinner startTimeSpinner = new JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.MINUTE));
    public JSpinner endTimeSpinner = new JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.MINUTE));

    // Ok and Cancel
    JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
    JButton okButton = new JButton();
    JButton cancelButton = new JButton();
    public boolean CANCELLED = true;

    public AddScheduleDialog(Frame frame, String title) {
        super(frame, title, true);
        try {
            jbInit();
            pack();
        }
        catch (Exception ex) {
            new ExceptionDialog(ex);
            ex.printStackTrace();
        }
    }

    private void jbInit() {
        this.setResizable(false);
        dialogTitlePanel.setBackground(Color.WHITE);
        dialogTitlePanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        header.setFont(new java.awt.Font("Dialog", 0, 20));
        header.setForeground(new Color(212, 19, 19));
        header.setText(Local.getString("New Schedule"));
        header.setIcon(new ImageIcon(main.java.memoranda.ui.AddPeopleDialog.class.getResource(
                "/ui/icons/tasks.png")));
        dialogTitlePanel.add(header);
        this.getContentPane().add(dialogTitlePanel, BorderLayout.NORTH);

        // Trainer Combo Box
        trainerLabel.setText("Trainer:");
        gridBagConstrains = new GridBagConstraints();
        gridBagConstrains.gridx = 0;
        gridBagConstrains.gridy = 1;
        gridBagConstrains.insets = new Insets(5, 20, 5, 5);
        gridBagConstrains.anchor = GridBagConstraints.WEST;
        gridBagConstrains.fill = GridBagConstraints.HORIZONTAL;
        areaPanel.add(trainerLabel, gridBagConstrains);

        Vector<People> people = CurrentProject.getPeopleList().getAllPeople();
        Vector<People> trainers = new Vector<People>();
        for (People person : people) {
            if (person instanceof Trainer) {
                trainers.add(person);
            }
        }
        String[] trainerNames = new String[trainers.size()];
        for (int i = 0; i < trainers.size(); i++) {
            trainerNames[i] = trainers.get(i).getName();
        }

        trainerOptionsBox = new JComboBox<>(trainerNames);

        trainerOptionsBox.setMinimumSize(new Dimension(4, 24));
        trainerOptionsBox.setPreferredSize(new Dimension(335, 24));

        trainerOptionsBox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                trainerOptionsBox_itemUpdate(e);
            }
        });

        gridBagConstrains = new GridBagConstraints();
        gridBagConstrains.gridx = 1;
        gridBagConstrains.gridy = 1;
        gridBagConstrains.gridwidth = 2;
        gridBagConstrains.insets = new Insets(5, 5, 0, 15);
        gridBagConstrains.anchor = GridBagConstraints.WEST;
        gridBagConstrains.fill = GridBagConstraints.HORIZONTAL;
        areaPanel.add(trainerOptionsBox, gridBagConstrains);
        this.getContentPane().add(areaPanel, BorderLayout.CENTER);

        // Start Time Text Field
        startTimeLabel.setText("Start Time:");
        gridBagConstrains = new GridBagConstraints();
        gridBagConstrains.gridx = 0;
        gridBagConstrains.gridy = 3;
        gridBagConstrains.insets = new Insets(5, 20, 5, 15);
        gridBagConstrains.anchor = GridBagConstraints.WEST;
        areaPanel.add(startTimeLabel, gridBagConstrains);
        startTimeSpinner.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                startTimeField_changeUpdate(e);
            }
        });

        gridBagConstrains = new GridBagConstraints();
        gridBagConstrains.gridx = 1;
        gridBagConstrains.gridy = 3;
        gridBagConstrains.gridwidth = 2;
        gridBagConstrains.insets = new Insets(5, 5, 0, 15);
        gridBagConstrains.anchor = GridBagConstraints.WEST;
        gridBagConstrains.fill = GridBagConstraints.HORIZONTAL;
        areaPanel.add(startTimeSpinner, gridBagConstrains);
        this.getContentPane().add(areaPanel, BorderLayout.CENTER);

        // End Time Text Field
        endTimeLabel.setText("End Time:");
        gridBagConstrains = new GridBagConstraints();
        gridBagConstrains.gridx = 0;
        gridBagConstrains.gridy = 4;
        gridBagConstrains.insets = new Insets(5, 20, 5, 15);
        gridBagConstrains.anchor = GridBagConstraints.WEST;
        areaPanel.add(endTimeLabel, gridBagConstrains);
        endTimeSpinner.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                endTimeField_changeUpdate(e);
            }
        });

        gridBagConstrains = new GridBagConstraints();
        gridBagConstrains.gridx = 1;
        gridBagConstrains.gridy = 4;
        gridBagConstrains.gridwidth = 2;
        gridBagConstrains.insets = new Insets(5, 5, 0, 15);
        gridBagConstrains.anchor = GridBagConstraints.WEST;
        gridBagConstrains.fill = GridBagConstraints.HORIZONTAL;
        areaPanel.add(endTimeSpinner, gridBagConstrains);
        this.getContentPane().add(areaPanel, BorderLayout.CENTER);

        okButton.setEnabled(trainers.size() > 0);
        okButton.setText(Local.getString("Ok"));
        okButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                okButton_actionPerformed(e);
            }
        });
        this.getRootPane().setDefaultButton(okButton);

        cancelButton.setText(Local.getString("Cancel"));
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cancelButton_actionPerformed(e);
            }
        });

        buttonsPanel.add(okButton);
        buttonsPanel.add(cancelButton);
        this.getContentPane().add(buttonsPanel, BorderLayout.SOUTH);
    }


    private void checkOkEnabled() {
        if (trainerOptionsBox.getSelectedItem() != null) {
            okButton.setEnabled(true);
        } else {
            okButton.setEnabled(false);
        }
    }

    private void okButton_actionPerformed(ActionEvent e) {
        CANCELLED = false;
        this.dispose();
    }

    /**
     * close the dialog window
     */

    void cancelButton_actionPerformed(ActionEvent e) {
        this.dispose();
    }

    private void trainerOptionsBox_itemUpdate(ItemEvent e) {
        checkOkEnabled();
    }

    private void startTimeField_changeUpdate(ChangeEvent e) {
        checkOkEnabled();
    }

    private void endTimeField_changeUpdate(ChangeEvent e) {
        checkOkEnabled();
    }
}
