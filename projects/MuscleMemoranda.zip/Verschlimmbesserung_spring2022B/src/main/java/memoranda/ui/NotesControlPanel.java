package main.java.memoranda.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTabbedPane;
import javax.swing.JToolBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import main.java.memoranda.CurrentNote;
import main.java.memoranda.CurrentProject;
import main.java.memoranda.Note;
import main.java.memoranda.date.CurrentDate;
import main.java.memoranda.util.Configuration;
import main.java.memoranda.util.Local;

/*$Id: NotesControlPanel.java,v 1.17 2022/04/22 9:59 PM hconigli $*/
public class NotesControlPanel extends JPanel {
    BorderLayout borderLayout1 = new BorderLayout();
    SearchPanel searchPanel = new SearchPanel();
    NotesListPanel notesListPanel = new NotesListPanel();
    BookmarksPanel bookmarksListPanel = new BookmarksPanel();
    JTabbedPane tabbedPane = new JTabbedPane();
    JToolBar toolBar = new JToolBar();
    
    int activeTab = 0;

    FlowLayout flowLayout1 = new FlowLayout();
    JButton ppOpenB = new JButton();
    JPanel buttonsPanel = new JPanel();
    JMenuItem ppAddBkmrk = new JMenuItem();
    JMenuItem ppClearNote = new JMenuItem();
	JCheckBoxMenuItem ppInvertSort = new JCheckBoxMenuItem();
    JPopupMenu notesPPMenu = new JPopupMenu();
    JMenuItem ppOpenNote = new JMenuItem();
    JMenuItem ppRemoveBkmrk = new JMenuItem();

	
    public NotesControlPanel() {
        try {
            jbInit();

        }
        catch (Exception ex) {
            new ExceptionDialog(ex);
        }
    }

    void jbInit() throws Exception {
        tabbedPane.setFont(new java.awt.Font("Serif", 1, 10));
        tabbedPane.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                tabbedPane_stateChanged(e);
            }
        });
        tabbedPane.setTabPlacement(JTabbedPane.BOTTOM);
        this.setLayout(borderLayout1);
        toolBar.setRequestFocusEnabled(false);
        toolBar.setFloatable(false);

        flowLayout1.setAlignment(FlowLayout.RIGHT);
        flowLayout1.setVgap(0);
        ppOpenB.setMaximumSize(new Dimension(34, 20));
        ppOpenB.setMinimumSize(new Dimension(24, 10));
        ppOpenB.setOpaque(false);
        ppOpenB.setPreferredSize(new Dimension(24, 20));
        ppOpenB.setBorderPainted(false);
        ppOpenB.setFocusPainted(false);
        ppOpenB.setMargin(new Insets(0, 0, 0, 0));
        ppOpenB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ppOpenB_actionPerformed(e);
            }
        });
        ppOpenB.setIcon(
            new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/nopen.png")));
        buttonsPanel.setMinimumSize(new Dimension(70, 22));
        buttonsPanel.setOpaque(false);
        buttonsPanel.setRequestFocusEnabled(false);
        buttonsPanel.setLayout(flowLayout1);
        ppAddBkmrk.setFont(new java.awt.Font("Serif", 1, 11));
        ppAddBkmrk.setText(Local.getString("Set bookmark"));
        ppAddBkmrk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ppAddBkmrk_actionPerformed(e);
            }
        });
        ppAddBkmrk.setIcon(
            new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/addbookmark.png")));
        ppClearNote.setFont(new java.awt.Font("Serif", 1, 11));
        ppClearNote.setText(Local.getString("Clear note"));
        ppClearNote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ppClearNote_actionPerformed(e);
            }
        });
        ppClearNote.setIcon(
            new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/editdelete.png")));
        ppClearNote.setEnabled(false);
        notesPPMenu.setFont(new java.awt.Font("Serif", 1, 10));
        ppOpenNote.setFont(new java.awt.Font("Serif", 1, 11));
        ppOpenNote.setText(Local.getString("Go to note"));
        ppOpenNote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ppOpenNote_actionPerformed(e);
            }
        });
        ppOpenNote.setEnabled(false);

        ppInvertSort.setFont(new java.awt.Font("Serif", 1, 11));
        ppInvertSort.setText(Local.getString("Invert Sort Order"));
        ppInvertSort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ppInvertSort_actionPerformed(e);
            }
        });
        ppInvertSort.setEnabled(true);
		boolean descSort =
			(Configuration.get("NOTES_SORT_ORDER").equals("true"));
		ppInvertSort.setSelected(descSort);
		
        ppRemoveBkmrk.setFont(new java.awt.Font("Serif", 1, 11));
        ppRemoveBkmrk.setText(Local.getString("Remove bookmark"));
        ppRemoveBkmrk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ppRemoveBkmrk_actionPerformed(e);
            }
        });
        ppRemoveBkmrk.setIcon(
            new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/removebookmark.png")));
        ppRemoveBkmrk.setEnabled(false);
        tabbedPane.add(searchPanel, Local.getString("Search"));        
	    tabbedPane.add(notesListPanel, Local.getString("Notes"));
        tabbedPane.add(bookmarksListPanel, Local.getString("Bookmarks"));
        this.add(toolBar, BorderLayout.NORTH);
        buttonsPanel.add(ppOpenB, null);
        toolBar.add(buttonsPanel, null);
        toolBar.addSeparator();        
        this.add(tabbedPane, BorderLayout.CENTER);

        PopupListener lst = new PopupListener();
        notesListPanel.getNotesList().addMouseListener(lst);
        bookmarksListPanel.getNotesList().addMouseListener(lst);
        searchPanel.getNotesList().addMouseListener(lst);
        ListSelectionListener lsl = new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
		ppSetEnabled();
            }
        };
        notesListPanel.getNotesList().getSelectionModel().addListSelectionListener(lsl);
        bookmarksListPanel.getNotesList().getSelectionModel().addListSelectionListener(lsl);
        searchPanel.getNotesList().getSelectionModel().addListSelectionListener(lsl);
        notesPPMenu.add(ppOpenNote);
        notesPPMenu.add(ppInvertSort);
        notesPPMenu.addSeparator();        
        notesPPMenu.add(ppAddBkmrk);
        notesPPMenu.add(ppRemoveBkmrk);
        notesPPMenu.addSeparator();
        notesPPMenu.add(ppClearNote);

		// remove notes using the DEL key
		KeyListener delNotes = new KeyListener() {
			public void keyPressed(KeyEvent e){
				if(e.getKeyCode()==KeyEvent.VK_DELETE) {
					ppClearNote_actionPerformed(null);
				}
			}
			public void	keyReleased(KeyEvent e){}
			public void keyTyped(KeyEvent e){} 
		};
		
		searchPanel.getNotesList().addKeyListener(delNotes);
		notesListPanel.getNotesList().addKeyListener(delNotes);
		bookmarksListPanel.getNotesList().addKeyListener(delNotes);
    }

    public void refresh() {
        searchPanel.getNotesList().update();
        notesListPanel.getNotesList().update();
        bookmarksListPanel.getNotesList().update();
        ppSetEnabled();
        CurrentProject.save();
    }

    void tabbedPane_stateChanged(ChangeEvent e) {
        switch (tabbedPane.getSelectedIndex()) {
            case 0 :
                activeTab = 0;
                break;
            case 1 :
                activeTab = 1;
                break;
            case 2 :
                activeTab = 2;
                break;
        }
        ppSetEnabled();
    }

    class PopupListener extends MouseAdapter {

        public void mouseClicked(MouseEvent e) {
            if (e.getClickCount() == 2) {
                if (activeTab == 0) {
                    setActiveNote(searchPanel.getNotesList().getSelectedNote());
                } else if (activeTab == 1) {
                    setActiveNote(notesListPanel.getNotesList().getSelectedNote());
                } else {
                    setActiveNote(bookmarksListPanel.getNotesList().getSelectedNote());
                }
            }
        }

        public void mousePressed(MouseEvent e) {
             maybeShowPopup(e);
         }
        
         public void mouseReleased(MouseEvent e) {
             maybeShowPopup(e);
         }
        
         private void maybeShowPopup(MouseEvent e) {
             if (e.isPopupTrigger()) {
                 notesPPMenu.show(e.getComponent(), e.getX(), e.getY());
             }
         }
    }
    
    void setActiveNote(Note selectedNote) {
        CurrentDate.set(selectedNote.getDate());
        CurrentNote.set(selectedNote,true);
    }
   

    void ppOpenB_actionPerformed(ActionEvent e) {
        notesPPMenu.show(
            toolBar,
            (int) ppOpenB.getLocation().getX(),
            (int) ppOpenB.getLocation().getY() + 24);
    }
    
    /**
     * Helper method for ppAddBkmrk so that this code does not need to be written for each tab
     * @param n NoteList we are currently working on
     */
    void ppAddBkmrkHelper(NotesList n) {
        for (int i = 0; i < n.getSelectedIndices().length; i++) {
            Note note = (Note) n.getNote(n.getSelectedIndices()[i]);
            note.setMark(true);
        }
    }

    void ppAddBkmrk_actionPerformed(ActionEvent e) {
        if (activeTab == 0) {
            ppAddBkmrkHelper(searchPanel.getNotesList());
        } else if (activeTab == 1) {
            ppAddBkmrkHelper(notesListPanel.getNotesList());
        } else {
            ppAddBkmrkHelper(bookmarksListPanel.getNotesList());
        }
        refresh();
    }
    
    /**
     * Helper for ppClearNote so this code does not need to be written for each tab. Capable of clearing one or many notes.
     * @param n NoteList we are currently working on
     */
    void ppClearNoteHelper(NotesList n) {
        String msg;
        if (n.getSelectedIndices().length > 1) {
            msg =
                Local.getString(Local.getString("Clear"))
                    + " "
                    + n.getSelectedIndices().length
                    + " "
                    + Local.getString("notes")
                    + "\n"
                    + Local.getString("Are you sure?");
        } else {
            msg =
                Local.getString("Clear note")
                    + "\n'"
                    + ((Note) n.getNote(n.getSelectedIndex())).getDate().getFullDateString()
                    + "'\n"
                    + Local.getString("Are you sure?");
        }
        int o = JOptionPane.showConfirmDialog(App.getFrame(), msg, Local.getString("Clear note"), JOptionPane.YES_NO_OPTION);
        if (o != JOptionPane.YES_OPTION) {
            return;
        }
        for (int i = 0; i < n.getSelectedIndices().length; i++) {
            Note note = (Note) n.getNote(n.getSelectedIndices()[i]);
            if (CurrentProject.getNoteList().getActiveNote() != null && note.getDate().equals(CurrentProject.getNoteList().getActiveNote().getDate())){
                CurrentNote.set(null,true);
            }
            CurrentProject.getNoteList().removeNote(note.getDate(), note.getId());
        }
    }
    
    /**
     *  Removes a note or selection of notes from the current list.
     */
    void ppClearNote_actionPerformed(ActionEvent e) {
        if (activeTab == 0) {
            ppClearNoteHelper(searchPanel.getNotesList());
        } else if (activeTab == 1) {
            ppClearNoteHelper(notesListPanel.getNotesList());
        } else {
            ppClearNoteHelper(bookmarksListPanel.getNotesList());
        }
        refresh();
    }
	
    void ppOpenNote_actionPerformed(ActionEvent e) {
        if (activeTab == 0) {
            setActiveNote(searchPanel.getNotesList().getSelectedNote());
        } else if (activeTab == 1) {
            setActiveNote(notesListPanel.getNotesList().getSelectedNote());
        } else {
            setActiveNote(bookmarksListPanel.getNotesList().getSelectedNote());
        }
        refresh();
    }
    
    /**
     * Helper for invert sort so that this code does not need to be repeated.
     * @param n NotesList we are currently working on
     */
    void ppInvertSortHelper(NotesList n) {
        Configuration.put(
                "NOTES_SORT_ORDER",
                new Boolean(ppInvertSort.isSelected()));
            Configuration.saveConfig();
            n.invertSortOrder();
    }

    void ppInvertSort_actionPerformed(ActionEvent e) {
        if (activeTab == 0) {
            ppInvertSortHelper(searchPanel.getNotesList());
        } else if (activeTab == 1) {
            ppInvertSortHelper(notesListPanel.getNotesList());
        } else {
            ppInvertSortHelper(bookmarksListPanel.getNotesList());
        }
        refresh();
    }
    
    /**
     * Helper method for ppRemoveBkmrk so that this code does not need to be written for all tabs.
     * @param n NotesList we are currently working on
     */
    void ppRemoveBkmrkHelper(NotesList n) {
        for (int i = 0; i < n.getSelectedIndices().length; i++) {
            Note note = (Note) n.getNote(n.getSelectedIndices()[i]);
            note.setMark(false);
            n.clearSelection();
        }
    }
    
    /**
     * Action to remove a bookmark from a selected entry.
     * @param e
     */
    void ppRemoveBkmrk_actionPerformed(ActionEvent e) {
        if (activeTab == 0) {
            ppRemoveBkmrkHelper(searchPanel.getNotesList());
        } else if (activeTab == 1) {
            ppRemoveBkmrkHelper(notesListPanel.getNotesList());
        } else {
            ppRemoveBkmrkHelper(bookmarksListPanel.getNotesList());
        }
        refresh();
        ((AppFrame)App.getFrame()).workPanel.dailyItemsPanel.editorPanel.editor.requestFocus();	
    }
    
    /**
     * A helper method so that this code is not written multiple times for the tabs.
     * @param n The NotesList we are currently working on
     */
    void ppSetEnabledHelper(NotesList n) {
        if ((n.getModel().getSize() > 0) 
                && (n.getSelectedIndex() > - 1)) {
            if ((n.getSelectedNote().isMarked()) 
                    || (n.getSelectedIndices().length > 1)) {
                ppRemoveBkmrk.setEnabled(true);
            } else {
                ppRemoveBkmrk.setEnabled(false);
            }
            if ((!n.getSelectedNote().isMarked()) 
                    || (n.getSelectedIndices().length > 1)) {
                ppAddBkmrk.setEnabled(true);
            } else {
                ppAddBkmrk.setEnabled(false);
            }
            ppOpenNote.setEnabled(true);
            ppClearNote.setEnabled(true);      
        } else {
            ppRemoveBkmrk.setEnabled(false);
            ppAddBkmrk.setEnabled(false);
            ppOpenNote.setEnabled(false);
            ppClearNote.setEnabled(false);
        }
    }
    
    /**
     * Sets the JMenuItems to enabled if their lists have more than one element
     * and conditions for use of the button are met.
     */
    void ppSetEnabled() {
        if (activeTab == 0) {
            ppSetEnabledHelper(searchPanel.getNotesList());
        } else if (activeTab == 1) {
            ppSetEnabledHelper(notesListPanel.getNotesList());
        } else {
            ppSetEnabledHelper(bookmarksListPanel.getNotesList());
        }
    }
}