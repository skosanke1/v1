package main.java.memoranda.ui;

import main.java.memoranda.*;
import java.util.Vector;
import main.java.memoranda.util.CurrentStorage;

import javax.swing.*;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;


public class TrainingTable extends JTable implements PeopleListNotificationListener, TrainerNotificationListener {
    public TrainerDataList trainerData = new TrainerDataList();

    public TrainingTable() {
        super();
        CurrentProject.getPeopleList().addListener(this);
        Vector<People> people = CurrentProject.getPeopleList().getAllPeople();
        for (People person : people) {
            if (person instanceof Trainer) {
                Trainer trainer = (Trainer)person;
                if (trainer.getSchedule().size() > 0) {
                    for (TrainerSchedule schedule : trainer.getSchedule()) {
                        trainerData.add(new TrainerData(trainer, schedule), false);
                    }
                } else {
                    trainerData.add(new TrainerData((Trainer) person), false);
                }
            }
        }
        trainerData.addListener(this);
        TableCellRenderer tableRenderer = getDefaultRenderer(JButton.class);
        setDefaultRenderer(JButton.class, new JTableButtonRenderer(tableRenderer));
        setFont(new Font("Dialog",0,11));
        setModel(new TrainingTableModel());
        updateUI();

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = rowAtPoint(e.getPoint());
                if (row < 0 || row >= getRowCount()) {
                    return;
                }
                int col = columnAtPoint(e.getPoint());
                if (col == 6) {
                    queryStudents(row);
                }
            }
        });
    }


    private void queryStudents(int row) {
        Frame frame = new Frame();
        Vector<People> people = CurrentProject.getPeopleList().getAllPeople();
        List<Student> students = new ArrayList<>();
        for (People person : people) {
            if (person instanceof Student) {
                students.add((Student)person);
            }
        }
        Object[] choices = new Object[students.size()];
        for (int i = 0; i < choices.length; i++) {
            choices[i] = students.get(i).getName();
        }

        String s = (String) JOptionPane.showInputDialog(frame, "Schedule for which student?",
                "Scheduler", JOptionPane.PLAIN_MESSAGE, UIManager.getIcon("OptionPane.questionIcon"),  choices, "");

        for (Student student : students) {
            if (student.getName().equals(s)) {
                student.addSchedule(trainerData.get(row).getSchedule());
                CurrentProject.getPeopleList().addSchedule(student, trainerData.scheduleGet(row).getSchedule());
                CurrentStorage.get().storePeopleList(CurrentProject.getPeopleList(), CurrentProject.get());
                break;
            }
        }
    }

    @Override
    public void beltRankChanged(People.BeltRank rank) {
        updateUI();
    }

    @Override
    public void trainingRankChanged(People.BeltRank rank) {
        updateUI();
    }

    @Override
    public void scheduleChanged() {
        updateUI();
    }

    @Override
    public void personAdded(People person) {
        updateUI();
    }

    @Override
    public void personRemoved(People person) {
        updateUI();
    }

    private class JTableButtonRenderer implements TableCellRenderer {
        private TableCellRenderer defaultRenderer;
        public JTableButtonRenderer(TableCellRenderer renderer) {
            defaultRenderer = renderer;
        }
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            if(value instanceof Component)
                return (Component)value;
            return defaultRenderer.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        }
    }

    private class TrainingTableModel extends AbstractTableModel {
        private final String[] titles = { "Name", "Rank", "Training Rank", "Start Time", "End Time", "Schedule" };

        @Override
        public int getRowCount() {
            return trainerData.scheduleSize();
        }

        @Override
        public int getColumnCount() {
            return titles.length;
        }

        @Override
        public String getColumnName(int columnIndex) {
            return titles[columnIndex];
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            switch (columnIndex) {
                case 0: return String.class;
                case 1: return People.BeltRank.class;
                case 2: return People.BeltRank.class;
                case 3: return String.class;
                case 4: return String.class;
                case 5: return JButton.class;
                default: return null;
            }
        }

        @Override
        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return false;
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            TrainerData data = trainerData.scheduleGet(rowIndex);
            if (rowIndex < 0 || rowIndex >= getRowCount() || data.getSchedule() == null) {
                return null;
            }
            switch (columnIndex) {
                case 0: 
                    return data.getTrainer().getName();
                case 1: 
                    return data.getTrainer().getBeltRank();
                case 2: 
                    return data.getTrainer().getTrainingRank();
                case 3:
                    return data.getSchedule().getFromTime();
                case 4:
                    return data.getSchedule().getToTime();
                case 5:
                    return data.getButton();
                default:
                    return null;
            }
        }

        @Override
        public void addTableModelListener(TableModelListener l) {
            super.addTableModelListener(l);
        }

        @Override
        public void removeTableModelListener(TableModelListener l) {
            super.removeTableModelListener(l);
        }
    }
}