package main.java.memoranda.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.*;

import javax.swing.*;

import main.java.memoranda.*;
import main.java.memoranda.CurrentProject;
import main.java.memoranda.util.*;

/*$Id: TaskPanel.java,v 1.27 2007/01/17 20:49:12 killerjoe Exp $*/
public class TrainingPanel extends JPanel {
    BorderLayout borderLayout1 = new BorderLayout();
    JToolBar tasksToolBar = new JToolBar();
    JButton newScheduleB = new JButton();
    JButton newTaskRandom = new JButton();
    JButton newTaskHealthTip = new JButton();
    JButton removeScheduleB = new JButton();
	JCheckBoxMenuItem ppShowActiveOnlyChB = new JCheckBoxMenuItem();
		
    JScrollPane scrollPane = new JScrollPane();
	JPopupMenu taskPPMenu = new JPopupMenu();
	JMenuItem ppRemoveSchedule = new JMenuItem();
	DailyItemsPanel parentPanel = null;

    TrainingTable trainingTable;

    public TrainingPanel(DailyItemsPanel _parentPanel) {
        try {
            parentPanel = _parentPanel;
            jbInit();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    void jbInit() throws Exception {
        tasksToolBar.setFloatable(false);

        newScheduleB.setIcon(
            new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/todo_new.png")));
        newScheduleB.setEnabled(true);
        newScheduleB.setMaximumSize(new Dimension(24, 24));
        newScheduleB.setMinimumSize(new Dimension(24, 24));
        newScheduleB.setToolTipText(Local.getString("Create new schedule"));
        newScheduleB.setRequestFocusEnabled(false);
        newScheduleB.setPreferredSize(new Dimension(24, 24));
        newScheduleB.setFocusable(false);
        newScheduleB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                newScheduleB_actionPerformed(e);
            }
        });
        newScheduleB.setBorderPainted(false);

        newTaskRandom.setIcon(
                new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/star8.png")));
        newTaskRandom.setEnabled(true);
        newTaskRandom.setMaximumSize(new Dimension(24, 24));
        newTaskRandom.setMinimumSize(new Dimension(24, 24));
        newTaskRandom.setToolTipText(Local.getString("Generate a random workout"));
        newTaskRandom.setRequestFocusEnabled(false);
        newTaskRandom.setPreferredSize(new Dimension(24, 24));
        newTaskRandom.setFocusable(false);
        newTaskRandom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    newTaskRandom_actionPerformed(e);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        newTaskRandom.setBorderPainted(false);

        newTaskHealthTip.setBorderPainted(false);
        newTaskHealthTip.setIcon(
                new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/help.png")));
        newTaskHealthTip.setEnabled(true);
        newTaskHealthTip.setMaximumSize(new Dimension(24, 24));
        newTaskHealthTip.setMinimumSize(new Dimension(24, 24));
        newTaskHealthTip.setToolTipText(Local.getString("Health Tip"));
        newTaskHealthTip.setRequestFocusEnabled(false);
        newTaskHealthTip.setPreferredSize(new Dimension(24, 24));
        newTaskHealthTip.setFocusable(false);
        newTaskHealthTip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    healthTip_actionPerformed(e);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        newTaskHealthTip.setBorderPainted(false);

        ppRemoveSchedule.setFont(new java.awt.Font("Dialog", 1, 11));
        ppRemoveSchedule.setText(Local.getString("Remove class"));
        ppRemoveSchedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ppRemoveSchedule_actionPerformed(e);
            }
        });
        ppRemoveSchedule.setIcon(
                new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/todo_remove.png")));
        ppRemoveSchedule.setEnabled(false);
        removeScheduleB.setBorderPainted(false);
        removeScheduleB.setFocusable(false);
        removeScheduleB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                removeScheduleB_actionPerformed(e);
            }
        });

        removeScheduleB.setPreferredSize(new Dimension(24, 24));
        removeScheduleB.setRequestFocusEnabled(false);
        removeScheduleB.setToolTipText(Local.getString("Remove task"));
        removeScheduleB.setMinimumSize(new Dimension(24, 24));
        removeScheduleB.setMaximumSize(new Dimension(24, 24));
        removeScheduleB.setIcon(
            new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/todo_remove.png")));

        this.setLayout(borderLayout1);
        scrollPane.getViewport().setBackground(Color.white);

        trainingTable = new TrainingTable();
        setLayout(new BorderLayout());
        add(trainingTable, BorderLayout.CENTER);

        this.add(scrollPane, BorderLayout.CENTER);

        tasksToolBar.add(newScheduleB, null);
        tasksToolBar.add(removeScheduleB, null);
        tasksToolBar.add(newTaskRandom, null);
        tasksToolBar.add(newTaskHealthTip, null);

        this.add(tasksToolBar, BorderLayout.NORTH);

        PopupListener ppListener = new PopupListener();
        scrollPane.addMouseListener(ppListener);
        trainingTable.addMouseListener(ppListener);

        trainingTable.setMaximumSize(new Dimension(32767, 32767));
        trainingTable.setRowHeight(24);
        scrollPane.getViewport().add(trainingTable, null);

        taskPPMenu.add(ppRemoveSchedule);
    }

    void newScheduleB_actionPerformed(ActionEvent e) {
        AddScheduleDialog dialog = new AddScheduleDialog(App.getFrame(), Local.getString("New schedule"));
        Dimension frameSize = App.getFrame().getSize();
        Point location = App.getFrame().getLocation();
        dialog.setLocation((frameSize.width - dialog.getSize().width) / 2 + location.x, (frameSize.height - dialog.getSize().height) / 2 + location.y);
        dialog.setVisible(true);

        if (dialog.CANCELLED) {
            return;
        }

        String trainerName = (String)dialog.trainerOptionsBox.getSelectedItem();
        Trainer trainer = null;
        for (People person : CurrentProject.getPeopleList().getAllPeople()) {
            if (person.getName() == trainerName && person instanceof Trainer) {
                trainer = (Trainer)person;
                break;
            }
        }

        if (trainer == null) {
            return;
        }

        String startTime = dialog.startTimeSpinner.getValue().toString();
        String endTime = dialog.endTimeSpinner.getValue().toString();

        TrainerSchedule schedule = new TrainerSchedule(trainerName, startTime, endTime);
        trainer.addSchedule(schedule);
        trainingTable.trainerData.add(new TrainerData(trainer, schedule), true);
        trainingTable.updateUI();
    }

    void newTaskRandom_actionPerformed(ActionEvent e) throws Exception {

        //msg will be what the user sees as their suggested workout
        String randomWorkoutString;
        int randomInteger;

        try {

            //grabbing random integer between 1 and 50 from custom Helper method
            randomInteger = RandomWorkoutHelper.generateRandomNum(1, 50);

            //plugging in randomInteger to get a random workout suggestion
            randomWorkoutString = RandomWorkoutHelper.getRandomWorkoutString(randomInteger);

            int n =
                    JOptionPane.showConfirmDialog(
                            App.getFrame(),
                            randomWorkoutString,
                            "Random Workout",
                            JOptionPane.CLOSED_OPTION);
            if (n != JOptionPane.CLOSED_OPTION)
                return;
        }
        catch(Exception ex){
            throw new Exception("Random number generator error: " + ex.getMessage());
        }


    }

    void healthTip_actionPerformed(ActionEvent e) throws Exception {

        //initializing variables
        String healthTip;
        int index;

        try {
            //get index
            index = main.java.memoranda.util.HealthTipHelper.getIndex(1, 50);
            healthTip = main.java.memoranda.util.HealthTipHelper.generateHealthTip(index);
            int n = JOptionPane.showConfirmDialog(App.getFrame(), healthTip, "Health Tip", JOptionPane.CLOSED_OPTION);
            if (n != JOptionPane.CLOSED_OPTION)
                return;
        } catch (Exception ex) {
            throw new Exception("Integer error: " + ex.getMessage());
        }
    }


    void removeScheduleB_actionPerformed(ActionEvent e) {
        if (trainingTable.trainerData.scheduleSize() == 0 || trainingTable.getSelectedRow() >= trainingTable.trainerData.scheduleSize()
            || trainingTable.getSelectedRow() < 0) {
            return;
        }
        trainingTable.trainerData.remove(trainingTable.getSelectedRow());
        trainingTable.updateUI();
    }

    class PopupListener extends MouseAdapter {
        public void mousePressed(MouseEvent e) {
            maybeShowPopup(e);
        }

        public void mouseReleased(MouseEvent e) {
            maybeShowPopup(e);
        }

        private void maybeShowPopup(MouseEvent e) {
            if (trainingTable.getSelectedRow() >= trainingTable.trainerData.scheduleSize() || trainingTable.getSelectedRow() < 0 || trainingTable.trainerData.scheduleSize() == 0) {
                ppRemoveSchedule.setEnabled(false);
            } else {
                ppRemoveSchedule.setEnabled(true);
            }
            if (e.isPopupTrigger()) {
                taskPPMenu.show(e.getComponent(), e.getX(), e.getY());
            }
        }

    }

    private void ppRemoveSchedule_actionPerformed(ActionEvent e) {
        removeScheduleB_actionPerformed(e);
    }
}