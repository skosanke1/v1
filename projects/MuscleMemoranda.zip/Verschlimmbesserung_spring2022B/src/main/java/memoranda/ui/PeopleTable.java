package main.java.memoranda.ui;

import java.awt.Component;
import java.awt.Font;
import java.util.Vector;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import main.java.memoranda.CurrentProject;
import main.java.memoranda.NoteList;
import main.java.memoranda.Project;
import main.java.memoranda.ProjectListener;
import main.java.memoranda.Trainer;
import main.java.memoranda.People;
import main.java.memoranda.PeopleList;
import main.java.memoranda.PeopleListNotificationListener;
import main.java.memoranda.TaskList;
import main.java.memoranda.ui.table.TableSorter;

/*$Id: PeoplesTable.java v1.0 04/14/2022 12:11 AM hconigli $*/
public class PeopleTable extends JTable {
    Vector<People> people = null;
    TableSorter sorter = null;

    public PeopleTable() {
        super();
        initTable();
        sorter = new TableSorter(new PeopleTableModel());
        sorter.addMouseListenerToHeaderInTable(this);
        setModel(sorter);
        this.setShowGrid(false);
        this.setFont(new Font("Dialog",0,11));
        initColumsWidth();
        this.setModel(new PeopleTableModel());
        CurrentProject.addProjectListener(new ProjectListener() {
            public void projectChange(Project p, NoteList nl, TaskList tl, PeopleList pl) {                
               
            }
            public void projectWasChanged() {
                 tableChanged();
            }
        });
    }

    void initColumsWidth() {
        for (int i = 0; i < 4; i++) {
            TableColumn column = getColumnModel().getColumn(i);
            if (i == 1) {
                column.setPreferredWidth(400);
            }
            else {
                column.setMinWidth(200);
                column.setPreferredWidth(200);
            }
        }
    }
    
    /**
     * Updates the table after it changes and saves the current project.
     */
    public void tableChanged() {
        people = CurrentProject.getPeopleList().getAllPeople();
        updateUI();
        CurrentProject.save();
    }
    
    public void tableChanged(String name, String attr, String value) {
        for (int i = 0; i < people.size(); i++) {
            if (people.get(i).getName().equals(name)) {
                if (attr.equals("belt rank")) {
                    people.get(i).setBeltRank(People.BeltRank.getRank(value));
                } else if (attr.equals("training rank")) {
                    ((Trainer)people.get(i)).setTrainingRank(People.BeltRank.getRank(value));
                } else {
                    return;
                }
            }
        }
        people = CurrentProject.getPeopleList().getAllPeople();
        updateUI();
        CurrentProject.save();
    }
    
    /**
     * Initializes table with peopleList data.
     */
    public void initTable() {
        people = CurrentProject.getPeopleList().getAllPeople();
    }
    
    public static final int _PEOPLE = 100;
    
    // I am not sure what this does -hconigli
    public TableCellRenderer getCellRenderer(int row, int column) {
        return new javax.swing.table.DefaultTableCellRenderer() {

            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, 
                    boolean hasFocus, int row, int column) {
                JLabel comp;
                comp = (JLabel)super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                return comp;
            }
       };
    }


    class PeopleTableModel extends AbstractTableModel {
        String[] columnNames = {
                "Title", // Student, trainer, owner
                "Name", // First and last name
                "Belt Rank",
                "Training Rank"};

        public String getColumnName(int i) {
            return columnNames[i];
        }

        public int getColumnCount() {
            return columnNames.length;
        }

        public int getRowCount() {
            return people.size();
        }
       
        /**
         * Returns People class value at a given row, column.
         */
        public Object getValueAt(int row, int col) {
            People p = (People)people.get(row);
            if (p.getTitle() == People.Title.TRAINER) {
                Trainer t = (Trainer) people.get(row);
                switch (col) {
                    case 0: return t.getTitle();
                    case 1: return t.getName();
                    case 2: return t.getBeltRank();
                    case 3: return t.getTrainingRank();
                }
            } else {
                switch (col) {
                    case 0: return p.getTitle();
                    case 1: return p.getName();
                    case 2: return p.getBeltRank();
                }
            }
            return null;
        }
        
        public Class getColumnClass(int col) {
            return getValueAt(0, col).getClass();
        }
    }
}