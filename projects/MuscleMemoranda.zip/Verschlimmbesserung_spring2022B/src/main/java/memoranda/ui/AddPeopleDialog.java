package main.java.memoranda.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;

import main.java.memoranda.People;
import main.java.memoranda.util.Local;

/*$Id: AddResourceDialog.java,v 1.12 2007/03/20 06:21:46 alexeya Exp $*/
public class AddPeopleDialog extends JDialog {
    JPanel dialogTitlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel header = new JLabel();
    ButtonGroup buttonGroup1 = new ButtonGroup();
    JPanel areaPanel = new JPanel(new GridBagLayout());
    GridBagConstraints gbc;
    
    // Labels for Text Fields
    JLabel title = new JLabel();
    JLabel name = new JLabel();
    JLabel beltRank = new JLabel();
    JLabel trainingRank = new JLabel();
    
    String titleOptions[] = {"Trainer", "Student", "Owner"};
    String beltOptions[] = {"White", "Yellow", "Orange", "Purple", "Blue", "Blue Stripe",
            "Green", "Green Stripe", "Brown 1", "Brown 2", "Brown 3", "Black 1", "Black 2", "Black 3"};
    
    // Text Fields
    public JComboBox<String> titleBox = new JComboBox<>(titleOptions);
    public JTextField nameField = new JTextField();
    public JComboBox<String> bRankBox = new JComboBox<>(beltOptions);
    public JComboBox<String> tRankBox = new JComboBox<>(beltOptions);
    
    // Ok and Cancel
    JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
    JButton okB = new JButton();
    JButton cancelB = new JButton();
    public boolean CANCELLED = true;

    /**
     *  adds people dialog.
     * @param frame frame
     * @param title title
     */
    public AddPeopleDialog(Frame frame, String title) {
        super(frame, title, true);
        try {
            jbInit();
            pack();
        }
        catch (Exception ex) {
            new ExceptionDialog(ex);
            ex.printStackTrace();
        }
    }

	/**
	 * setup user interface and init dialog.
	 */
    void jbInit() throws Exception {
		this.setResizable(false);
        dialogTitlePanel.setBackground(Color.WHITE);
        dialogTitlePanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        header.setFont(new java.awt.Font("Dialog", 0, 20));
        header.setForeground(new Color(212, 19, 19));
        header.setText(Local.getString("New Person"));
        header.setIcon(new ImageIcon(main.java.memoranda.ui.AddPeopleDialog.class.getResource(
            "/ui/icons/resource48.png")));
        dialogTitlePanel.add(header);
        this.getContentPane().add(dialogTitlePanel, BorderLayout.NORTH);

        // Title Text Field
        title.setText("Title:");
        gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.insets = new Insets(5, 20, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        areaPanel.add(title, gbc);
        titleBox.setMinimumSize(new Dimension(4, 24));
        titleBox.setPreferredSize(new Dimension(335, 24));
        titleBox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                titleBox_update(e);
            }
        });
        
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(5, 5, 0, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        areaPanel.add(titleBox, gbc);
        this.getContentPane().add(areaPanel, BorderLayout.CENTER);

        // Name Text Field
        name.setText("Name:");
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.insets = new Insets(5, 20, 5, 15);
        gbc.anchor = GridBagConstraints.WEST;
        areaPanel.add(name, gbc);
        nameField.setMinimumSize(new Dimension(4, 24));
        nameField.setPreferredSize(new Dimension(335, 24));
        nameField.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(CaretEvent e) {
                nameField_caretUpdate(e);
            }
        });
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(5, 5, 0, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        areaPanel.add(nameField, gbc);
        this.getContentPane().add(areaPanel, BorderLayout.CENTER);

        // Belt Rank Text Field
        beltRank.setText("Belt Rank:");
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.insets = new Insets(5, 20, 5, 15);
        gbc.anchor = GridBagConstraints.WEST;
        areaPanel.add(beltRank, gbc);
        bRankBox.setMinimumSize(new Dimension(4, 24));
        bRankBox.setPreferredSize(new Dimension(335, 24));
        
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(5, 5, 0, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        areaPanel.add(bRankBox, gbc);
        this.getContentPane().add(areaPanel, BorderLayout.CENTER);
        
        // Training Rank Text Field
        trainingRank.setText("Training Rank:");
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.insets = new Insets(5, 20, 5, 15);
        gbc.anchor = GridBagConstraints.WEST;
        areaPanel.add(trainingRank, gbc);
        tRankBox.setMinimumSize(new Dimension(4, 24));
        tRankBox.setPreferredSize(new Dimension(335, 24));
        
        
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(5, 5, 0, 15);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        areaPanel.add(tRankBox, gbc);
        this.getContentPane().add(areaPanel, BorderLayout.CENTER);
        
        // Cancel and okay button
        okB.setEnabled(true);
        okB.setMaximumSize(new Dimension(100, 26));
        okB.setMinimumSize(new Dimension(100, 26));
        okB.setPreferredSize(new Dimension(100, 26));
        okB.setText(Local.getString("Ok"));
        okB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                okB_actionPerformed(e);
            }
        });
        this.getRootPane().setDefaultButton(okB);
        cancelB.setMaximumSize(new Dimension(100, 26));
        cancelB.setMinimumSize(new Dimension(100, 26));
        cancelB.setPreferredSize(new Dimension(100, 26));
        cancelB.setText(Local.getString("Cancel"));
        cancelB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cancelB_actionPerformed(e);
            }
        });
        buttonsPanel.add(okB);
        buttonsPanel.add(cancelB);
		enableFields();
        this.getContentPane().add(buttonsPanel, BorderLayout.SOUTH);
    }


    /**
	 * set CANCELLED variable to false so we can know the user 
	 * pressed the ok button and close this dialog.
	 */
	 
    void okB_actionPerformed(ActionEvent e) {
        CANCELLED = false;
		this.dispose();
    }

	/**
	 * close the dialog window
	 */
	 
    void cancelB_actionPerformed(ActionEvent e) {
        this.dispose();
    }

	/**
	 * disable the ok button if titleBox is empty
	 */
    void titleBox_update(ItemEvent e) {
        if (titleBox.getSelectedItem().equals("Trainer")) {
            tRankBox.setVisible(true);
            trainingRank.setVisible(true);
        } else {
            tRankBox.setVisible(false);
            trainingRank.setVisible(false);
        }
        checkOkEnabled();
    }

	/**
	 * disable the ok button if nameField is empty
	 */
    void nameField_caretUpdate(CaretEvent e) {        
        checkOkEnabled();
    }
    
	/**
	 * Enable ok button when titleBox, nameField and bRankBox are filled, unless its a trainer.
	 * then wait for tRankBox as well.
	 */
    void checkOkEnabled() {
        if (nameField.getText().length() > 0) {
            okB.setEnabled(true);
        } else {
            okB.setEnabled(false);
        }
    }

    /**
     * enable and disable fields when user selects the radio buttons options.
     */
	void enableFields() {
        title.setEnabled(true);
         name.setEnabled(true);
         beltRank.setEnabled(true);
         trainingRank.setEnabled(true);
         titleBox.setEnabled(true);
         nameField.setEnabled(true);
         bRankBox.setEnabled(true);
         tRankBox.setEnabled(true);
    }
}