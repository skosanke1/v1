package main.java.memoranda.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import main.java.memoranda.CurrentProject;
import main.java.memoranda.PeopleList;
import main.java.memoranda.ui.PeopleTable.PeopleTableModel;

import javax.swing.*;

/*$Id: PeoplePanel.java v1.0 04/14/2022 12:13 AM hconigli $*/
public class PeoplePanel extends JPanel {
    BorderLayout borderLayout1 = new BorderLayout();
    JToolBar toolBar = new JToolBar();
    JButton newPersonB = new JButton();
    JButton removePersonB = new JButton();
    JButton refreshB = new JButton();
    PeopleTable peopleTable = new PeopleTable();
    JScrollPane scrollPane = new JScrollPane();
    JPopupMenu personPPMenu = new JPopupMenu();
    JMenuItem ppRemovePerson = new JMenuItem();
    JMenuItem ppNewPerson = new JMenuItem();
    JMenuItem ppRefresh = new JMenuItem();

    public PeoplePanel() {
        try {
            jbInit();
        }
        catch (Exception ex) {
           new ExceptionDialog(ex);
        }
    }
    void jbInit() throws Exception {
        toolBar.setFloatable(false);
        this.setLayout(borderLayout1);
        newPersonB.setIcon(
            new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/addresource.png")));
        newPersonB.setEnabled(true);
        newPersonB.setMaximumSize(new Dimension(24, 24));
        newPersonB.setMinimumSize(new Dimension(24, 24));
        newPersonB.setToolTipText("Add Person");
        newPersonB.setRequestFocusEnabled(false);
        newPersonB.setPreferredSize(new Dimension(24, 24));
        newPersonB.setFocusable(false);
        newPersonB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                newPersonB_actionPerformed(e);
            }
        });
        newPersonB.setBorderPainted(false);
        peopleTable.setMaximumSize(new Dimension(32767, 32767));
        peopleTable.setRowHeight(24);
        removePersonB.setBorderPainted(false);
        removePersonB.setFocusable(false);
        removePersonB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                removePersonB_actionPerformed(e);
            }
        });
        removePersonB.setPreferredSize(new Dimension(24, 24));
        removePersonB.setRequestFocusEnabled(false);
        removePersonB.setToolTipText("Remove Person");
        removePersonB.setMinimumSize(new Dimension(24, 24));
        removePersonB.setMaximumSize(new Dimension(24, 24));
        removePersonB.setIcon(
            new ImageIcon(
                main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/removeresource.png")));
        removePersonB.setEnabled(false);
        scrollPane.getViewport().setBackground(Color.white);
        toolBar.addSeparator(new Dimension(8, 24));
        toolBar.addSeparator(new Dimension(8, 24));


        PopupListener ppListener = new PopupListener();
        scrollPane.addMouseListener(ppListener);
        peopleTable.addMouseListener(ppListener);

        peopleTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                boolean enbl = (peopleTable.getRowCount() > 0) && (peopleTable.getSelectedRow() > -1);

                removePersonB.setEnabled(enbl); ppRemovePerson.setEnabled(enbl);
            }
        });
        refreshB.setBorderPainted(false);
        refreshB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                refreshB_actionPerformed(e);
            }
        });
        refreshB.setFocusable(false);
        refreshB.setPreferredSize(new Dimension(24, 24));
        refreshB.setRequestFocusEnabled(false);
        refreshB.setToolTipText("Refresh");
        refreshB.setMinimumSize(new Dimension(24, 24));
        refreshB.setMaximumSize(new Dimension(24, 24));
        refreshB.setEnabled(true);
        refreshB.setIcon(
            new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/refreshres.png")));
        personPPMenu.setFont(new java.awt.Font("Dialog", 1, 10));

    ppRemovePerson.setFont(new java.awt.Font("Dialog", 1, 11));
    ppRemovePerson.setText("Remove Person");
    ppRemovePerson.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ppRemoveRes_actionPerformed(e);
            }
        });
    ppRemovePerson.setIcon(new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/removeresource.png")));
    ppRemovePerson.setEnabled(false);
    ppNewPerson.setFont(new java.awt.Font("Dialog", 1, 11));
    ppNewPerson.setText("New person...");
    ppNewPerson.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ppNewPerson_actionPerformed(e);
            }
        });
    ppNewPerson.setIcon(new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/addresource.png")));

    ppRefresh.setFont(new java.awt.Font("Dialog", 1, 11));
    ppRefresh.setText("Refresh");
    ppRefresh.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        ppRefresh_actionPerformed(e);
      }
    });
    ppRefresh.setIcon(new ImageIcon(main.java.memoranda.ui.AppFrame.class.getResource("/ui/icons/refreshres.png")));

    toolBar.add(newPersonB, null);
        toolBar.add(removePersonB, null);
        toolBar.addSeparator();
        toolBar.add(refreshB, null);
        this.add(scrollPane, BorderLayout.CENTER);
        scrollPane.getViewport().add(peopleTable, null);
        this.add(toolBar, BorderLayout.NORTH);
    personPPMenu.addSeparator();
    personPPMenu.add(ppNewPerson);
    personPPMenu.add(ppRemovePerson);
    personPPMenu.addSeparator();
    personPPMenu.add(ppRefresh);
	
		// remove resources using the DEL key
		peopleTable.addKeyListener(new KeyListener() {
			public void keyPressed(KeyEvent e){
				if(peopleTable.getSelectedRows().length>0 
					&& e.getKeyCode()==KeyEvent.VK_DELETE)
					ppRemoveRes_actionPerformed(null);
			}
			public void	keyReleased(KeyEvent e){}
			public void keyTyped(KeyEvent e){} 
		});
    }
    
    /**
     * Reads input from text fields in dialogue and adds the person to the table and the project's list.
     */
    void newPersonB_actionPerformed(ActionEvent e) {
        AddPeopleDialog dlg = new AddPeopleDialog(App.getFrame(), "Add Person");
        Dimension frmSize = App.getFrame().getSize();
        Point loc = App.getFrame().getLocation();
        dlg.setLocation((frmSize.width - dlg.getSize().width) / 2 + loc.x, (frmSize.height - dlg.getSize().height) / 2 + loc.y);
        dlg.setVisible(true);
        if (dlg.CANCELLED) {
            return;
        }
        String title = (String)dlg.titleBox.getSelectedItem();
        String name = dlg.nameField.getText();
        String beltRank = (String)dlg.bRankBox.getSelectedItem();
        String trainingRank = (String)dlg.tRankBox.getSelectedItem();
        CurrentProject.getPeopleList().addPerson(title, name, beltRank, trainingRank, new ArrayList<>());
        peopleTable.tableChanged();
    }
    
    /**
     * Removes the selected person/people from the table and list.
     */
    void removePersonB_actionPerformed(ActionEvent e) {
        int[] toRemove = peopleTable.getSelectedRows();
        String msg = "";
        String name;
        if (toRemove.length == 1) {
            name = (String)peopleTable.getModel().getValueAt(toRemove[0], 1);
            msg = "Remove" + "\n'" + peopleTable.getModel().getValueAt(toRemove[0], 1) + "'";
        } else {
            msg = "Remove " + toRemove.length + " people";
            msg += "\n Are you sure?";
            int n = JOptionPane.showConfirmDialog(App.getFrame(), msg, "Remove Person", JOptionPane.YES_NO_OPTION);
            if (n != JOptionPane.YES_OPTION) {
                return;
            }
        }
        for (int i = 0; i < toRemove.length; i++) {
            name = (String)peopleTable.getModel().getValueAt(toRemove[i], 1);
            CurrentProject.getPeopleList().removePerson(name);
        }
        peopleTable.tableChanged();
    }
    
    

    class PopupListener extends MouseAdapter {

        public void mouseClicked(MouseEvent e) {
            if ((e.getClickCount() == 2) && (peopleTable.getSelectedRow() > -1)) {
                String name = (String) peopleTable.getValueAt(peopleTable.getSelectedRow(), 1);
                String msg;
                String toEdit = "";
                switch (peopleTable.getSelectedColumn()) {
                    case 0:
                        return;
                    case 1:
                        return;
                    case 2:
                        toEdit = "belt rank";
                        break;
                    case 3:
                        toEdit = "training rank";
                        break;
                }
                msg = "Edit " + name + "'s " + toEdit + ".";
                String choice[] = {"White", "Yellow", "Orange", "Purple", "Blue", "Blue Stripe",
                        "Green", "Green Stripe", "Brown 1", "Brown 2", "Brown 3", "Black 1", "Black 2", "Black 3"};
                String input = "";
                switch (toEdit) {
                    case "belt rank":
                        input = (String)JOptionPane.showInputDialog(App.getFrame(), msg, "Edit Belt Rank", JOptionPane.QUESTION_MESSAGE, null, choice, choice);
                        CurrentProject.getPeopleList().setPersonAttr(name, "beltRank", input);
                        break;
                    case "training rank":
                        input = (String)JOptionPane.showInputDialog(App.getFrame(), msg, "Edit Training Rank", JOptionPane.QUESTION_MESSAGE, null, choice, choice);
                        CurrentProject.getPeopleList().setPersonAttr(name, "trainingRank", input);
                        break;
                }
                peopleTable.tableChanged();
            }
        }
    }
    
    // Action Performed
    void refreshB_actionPerformed(ActionEvent e) {
        peopleTable.tableChanged();
    }
    
    void ppRemoveRes_actionPerformed(ActionEvent e) {
        removePersonB_actionPerformed(e);
    }
    
    void ppNewPerson_actionPerformed(ActionEvent e) {
        newPersonB_actionPerformed(e);
    }

    void ppRefresh_actionPerformed(ActionEvent e) {
        peopleTable.tableChanged();
    }
    
}