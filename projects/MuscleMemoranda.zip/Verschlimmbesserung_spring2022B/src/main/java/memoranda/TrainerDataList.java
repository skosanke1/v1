package main.java.memoranda;

import main.java.memoranda.util.CurrentStorage;

import java.util.ArrayList;
import java.util.List;

public class TrainerDataList implements PeopleListNotificationListener {
    private List<TrainerData> data = new ArrayList<>();
    private List<TrainerData> scheduledData = new ArrayList<>();

    private List<TrainerNotificationListener> listeners = new ArrayList<>();

    public TrainerDataList() {
        CurrentProject.getPeopleList().addListener(this);
    }

    public void add(TrainerData data, boolean store) {
        this.data.add(data);
        if (data.getSchedule() != null) {
            scheduledData.add(data);
        }
        for (TrainerData d : this.data) {
            if (d.getTrainer() == data.getTrainer()) {
                if (store) {
                    CurrentProject.getPeopleList().addSchedule(data.getTrainer(), data.getSchedule());
                }
                break;
            }
        }

        CurrentStorage.get().storePeopleList(CurrentProject.getPeopleList(), CurrentProject.get());
        for (TrainerNotificationListener listener : listeners) {
            listener.scheduleChanged();
        }
    }

    public void remove(TrainerData data) {
        CurrentProject.getPeopleList().removeSchedule(data.getTrainer(), data.getSchedule());
        CurrentStorage.get().storePeopleList(CurrentProject.getPeopleList(), CurrentProject.get());
        for (TrainerNotificationListener listener : listeners) {
            listener.scheduleChanged();
        }
    }

    public void remove(int index) {
        TrainerData trainerData = scheduledData.get(index);
        this.scheduledData.remove(index);
        data.remove(trainerData);
        remove(trainerData);
    }

    public TrainerData get(int i) {
        return data.get(i);
    }

    public TrainerData scheduleGet(int i) {
        return scheduledData.get(i);
    }

    public int size() {
        return data.size();
    }

    public int scheduleSize() {
        return scheduledData.size();
    }

    public List<TrainerData> getData() {
        return data;
    }

    public void clear() {
        data.clear();
    }

    public void addListener(TrainerNotificationListener l) {
        listeners.add(l);
    }

    public void removeListener(TrainerNotificationListener l) {
        listeners.remove(l);
    }

    @Override
    public void personAdded(People person) {
        if (person instanceof Trainer) {
            data.add(new TrainerData((Trainer)person));
        }
    }

    @Override
    public void personRemoved(People person) {
        for (int i = data.size() - 1; i >= 0; i--) {
            if (data.get(i).getTrainer() == person) {
                data.remove(i);
            }
        }
        for (int i = scheduledData.size() - 1; i >= 0; i--) {
            if (scheduledData.get(i).getTrainer() == person) {
                scheduledData.remove(i);
            }
        }
    }
}
