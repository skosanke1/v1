package main.java.memoranda.date;

public enum DayOfWeek {
    Monday,
    Tuesday,
    Wednesday,
    Thursday,
    Friday,
    Saturday,
    Sunday;

    public static DayOfWeek fromString(String s) {
        switch (s) {
            case "Monday": return DayOfWeek.Monday;
            case "Tuesday": return DayOfWeek.Tuesday;
            case "Wednesday": return DayOfWeek.Wednesday;
            case "Thursday": return DayOfWeek.Thursday;
            case "Friday": return DayOfWeek.Friday;
            case "Saturday": return DayOfWeek.Saturday;
            case "Sunday": return DayOfWeek.Sunday;
            default: return null;
        }
    }
}
