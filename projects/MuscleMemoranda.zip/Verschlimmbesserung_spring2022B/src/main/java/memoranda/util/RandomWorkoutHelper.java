package main.java.memoranda.util;

public class RandomWorkoutHelper {

    public static int generateRandomNum(int min, int max) throws Exception{

        //initializing random num variable
        int finalRandomNum = 0;

        //generating random number
        finalRandomNum = (int)(Math.random()*(max-min+1)+min);

        if(finalRandomNum < 0){
            throw new Exception("Error generating random number, it ended up being below 0. Try again.");
        }
        else if(finalRandomNum > 1000){
            throw new Exception("Error generating random number, too large for our bounds. Keep it under 100.");
        }
        else{
            return finalRandomNum;
        }
    }

    public static String getRandomWorkoutString(int n) throws Exception{

        String randomWorkoutString = "Run";

        switch(n) {
            case 1:
                randomWorkoutString = "Bicycle";
                break;
            case 2:
                randomWorkoutString = "Bicycle";
                break;
            case 3:
                randomWorkoutString = "Swim";
                break;
            case 4:
                randomWorkoutString = "Walk";
                break;
            case 5:
                randomWorkoutString = "Jog";
                break;
            case 6:
                randomWorkoutString = "Walk an animal";
                break;
            case 7:
                randomWorkoutString = "Bench Press";
                break;
            case 8:
                randomWorkoutString = "Do 50 squats";
                break;
            case 9:
                randomWorkoutString = "Take a rest day. You deserve it.";
                break;
            case 10:
                randomWorkoutString = "Spar with a partner";
                break;
            case 11:
                randomWorkoutString = "Hit the heavy bag.";
                break;
            case 12:
                randomWorkoutString = "Try a yoga class";
                break;
            case 13:
                randomWorkoutString = "Palates";
                break;
            case 14:
                randomWorkoutString = "Lower Row";
                break;
            case 15:
                randomWorkoutString = "Pull-ups";
                break;
            case 16:
                randomWorkoutString = "Dips";
                break;
            case 17:
                randomWorkoutString = "100 Jumping Jacks";
                break;
            case 18:
                randomWorkoutString = "20 Burpees";
                break;
            case 19:
                randomWorkoutString = "Dance";
                break;
            case 20:
                randomWorkoutString = "Plank";
                break;
            case 21:
                randomWorkoutString = "Lunge";
                break;
            case 22:
                randomWorkoutString = "Bridge";
                break;
            case 23:
                randomWorkoutString = "Step up";
                break;
            case 24:
                randomWorkoutString = "Bear Crawl";
                break;
            case 25:
                randomWorkoutString = "50 Mountain Climbers";
                break;
            case 26:
                randomWorkoutString = "Stair stepper (10 mins)";
                break;
            case 27:
                randomWorkoutString = "Walkout";
                break;
            case 28:
                randomWorkoutString = "Wall-sit (2 minutes)";
                break;
            case 29:
                randomWorkoutString = "Pistol Squat";
                break;
            case 30:
                randomWorkoutString = "Lunge Jump";
                break;
            case 31:
                randomWorkoutString = "Dead lift";
                break;
            case 32:
                randomWorkoutString = "Leg Lift";
                break;
            case 33:
                randomWorkoutString = "Calf-raise";
                break;
            case 34:
                randomWorkoutString = "Dolphin push-ups";
                break;
            case 35:
                randomWorkoutString = "Triangle push-ups";
                break;
            case 36:
                randomWorkoutString = "Handstand push-up";
                break;
            case 37:
                randomWorkoutString = "Judo push-up";
                break;
            case 38:
                randomWorkoutString = "Reverse fly";
                break;
            case 39:
                randomWorkoutString = "Superman";
                break;
            case 40:
                randomWorkoutString = "Tricep dips";
                break;
            case 41:
                randomWorkoutString = "Diamond push-ups";
                break;
            case 42:
                randomWorkoutString = "Box";
                break;
            case 43:
                randomWorkoutString = "Rotational push-up";
                break;
            case 44:
                randomWorkoutString = "Flutter kick!";
                break;
            case 45:
                randomWorkoutString = "Dynamix prone plank";
                break;
            case 46:
                randomWorkoutString = "P90x!";
                break;
            case 47:
                randomWorkoutString = "Side plank";
                break;
            case 48:
                randomWorkoutString = "Russian twist";
                break;
            case 49:
                randomWorkoutString = "Crunches";
                break;
            case 50:
                randomWorkoutString = "Abdominal press";
                break;
        }




        //return String retrieved from switch-statement
        return randomWorkoutString;
    }

}
