package main.java.memoranda.util;

public class HealthTipHelper {

    public static int getIndex(int min, int max) throws Exception{

        //initializing random num variable
        int index = 1;

        //generating random number
        index = (int)(Math.random()*(max-min+1)+min);

        if(index < 0){
            throw new Exception("Index cannot be below 0");
        }
        else if(index > 100){
            throw new Exception("Index cannot be above 100");
        }
        else{
            return index;
        }
    }

    public static String generateHealthTip(int n) throws Exception {

        String healthTip = "Stretch more";

        switch (n) {
            case 1:
                healthTip = "Eat less carbohydrates";
                break;
            case 2:
                healthTip = "Rethink your diet";
                break;
            case 3:
                healthTip = "Stretch after your workout, not before.";
                break;
            case 4:
                healthTip = "Focus on recovery";
                break;
            case 5:
                healthTip = "Breathe deeply and slowly after a set";
                break;
            case 6:
                healthTip = "Get motivated BEFORE your workout";
                break;
            case 7:
                healthTip = "Eat voluminous foods";
                break;
            case 8:
                healthTip = "Make your last set your best set";
                break;
            case 9:
                healthTip = "Make sure to take a rest day";
                break;
            case 10:
                healthTip = "Add more fruits and vegetables to replace sweets in your diet";
                break;
            case 11:
                healthTip = "Eat colorful foods";
                break;
            case 12:
                healthTip = "Eat higher-quality meat";
                break;
            case 13:
                healthTip = "Try to meditate";
                break;
            case 14:
                healthTip = "Go to sleep earlier";
                break;
            case 15:
                healthTip = "Live in the moment.";
                break;
            case 16:
                healthTip = "Lower your portion size";
                break;
            case 17:
                healthTip = "Try bodyweight exercises";
                break;
            case 18:
                healthTip = "Try broccoli! Its good, seriously";
                break;
            case 19:
                healthTip = "Replace sweets with water";
                break;
            case 20:
                healthTip = "Drink tea";
                break;
        }


        //return health tip
        return healthTip;
    }
}
