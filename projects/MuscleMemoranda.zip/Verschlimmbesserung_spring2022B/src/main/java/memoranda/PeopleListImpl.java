package main.java.memoranda;

import main.java.memoranda.util.CurrentStorage;
import main.java.memoranda.util.Util;
import main.java.memoranda.People;
import main.java.memoranda.People.BeltRank;
import main.java.memoranda.Trainer;
import nu.xom.Attribute;
import nu.xom.Document;
import nu.xom.Element;
import nu.xom.Elements;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

public class PeopleListImpl implements PeopleList {
    
    private Project _project = null;
    private Document _doc = null;
    private Element _root = null;

    private List<PeopleListNotificationListener> listeners = new ArrayList<>();

    private HashMap<String, People> peopleInstances = new HashMap<>();
    
    public PeopleListImpl(Document doc, Project prj) {
        _doc = doc;
        _root = _doc.getRootElement();
        _project = prj;
    }
    
    public PeopleListImpl(Project prj) {
        _root = new Element("people-list");
        _doc = new Document(_root);
        _project = prj;
}
    /**
     * Returns a Vector of all people within the _root.
     */
    public Vector<People> getAllPeople() {
        Vector<People> vector = new Vector<People>();
        Elements people = _root.getChildElements("people");
        for (int i = 0; i < people.size(); i++) {
            if (peopleInstances.containsKey(people.get(i).getAttribute("name").getValue())) {
                vector.add(peopleInstances.get(people.get(i).getAttribute("name").getValue()));
                continue;
            }
            ArrayList<String> schedules = new ArrayList<String>();
            for (int j = 0; j < people.get(i).getAttributeCount(); j++) {
                Attribute attribute = people.get(i).getAttribute(j);
                if (attribute.getLocalName().contains("schedule")) {
                    schedules.add(attribute.getValue());
                }
            }
            vector.add(createPerson(people.get(i).getAttribute("title").getValue(),
                    people.get(i).getAttribute("name").getValue(),
                    people.get(i).getAttribute("beltRank").getValue(),
                    people.get(i).getAttribute("trainingRank").getValue(),
                    schedules));
        }
        return vector;
    }
    
    /* For debugging, prints all people in _root */
    public void printAllPeople() {
        Elements people = _root.getChildElements("people");
        for (int i = 0; i < people.size(); i++) {
            System.out.println(people.get(i).getAttribute("title").getValue());
            System.out.println(people.get(i).getAttribute("name").getValue());
            System.out.println(people.get(i).getAttribute("beltRank").getValue());
            System.out.println(people.get(i).getAttribute("trainingRank").getValue());
            for (int j = 0; j < people.get(i).getAttributeCount(); j++) {
                Attribute attribute = people.get(i).getAttribute(j);
                if (attribute.getLocalName().contains("schedule")) {
                    System.out.println(attribute.getValue());
                }
            }
        }
    }
    
    /**
     * Creates a People object, either an Owner, Student, or Trainer, based on all String arguments.
     */
    public People createPerson(String title, String name, String beltRank, String trainingRank, List<String> schedules) {
        if (peopleInstances.containsKey(name)) {
            return peopleInstances.get(name);
        }
        People person;
        if (title.equals(People.Title.OWNER.toString())) {
            person = new Owner(name, BeltRank.getRank(beltRank));
        } else if (title.equals(People.Title.STUDENT.toString())) {
            Student student = new Student(name, BeltRank.getRank(beltRank));
            if (!schedules.isEmpty()) {
                for (String schedule : schedules) {
                    TrainerSchedule scheduleInstance = TrainerSchedule.fromString(schedule);
                    if (scheduleInstance != null) {
                        student.addSchedule(scheduleInstance);
                    }
                }
            }

            person = student;
        } else {
            Trainer trainer = new Trainer(name, BeltRank.getRank(beltRank), BeltRank.getRank(trainingRank));
            for (String schedule : schedules) {
                TrainerSchedule scheduleInstance = TrainerSchedule.fromString(schedule);
                if (scheduleInstance != null) {
                    trainer.addSchedule(scheduleInstance);
                }
            }
            person = trainer;
        }
        peopleInstances.put(person.getName(), person);
        CurrentStorage.get().storePeopleList(this, CurrentProject.get());
        return person;
    }
    
    /**
     * Returns a new person object based on the person searched using name.
     */
    public People getPerson(String name) {
        if (peopleInstances.containsKey(name)) {
            return peopleInstances.get(name);
        }
        Elements people = _root.getChildElements("people");
        System.out.println(people.get(0).getAttribute("id").getValue());
        for (int i = 0; i < people.size(); i++) {
            if (people.get(i).getAttribute("name").getValue().equals(name)) {
                ArrayList<String> schedules = new ArrayList<String>();
                for (int j = 0; j < people.get(i).getAttributeCount(); j++) {
                    Attribute attribute = people.get(i).getAttribute(j);
                    if (attribute.getLocalName().contains("schedule")) {
                        schedules.add(attribute.getValue());
                    }
                }
                return createPerson(people.get(i).getAttribute("title").getValue(),
                    people.get(i).getAttribute("name").getValue(),
                    people.get(i).getAttribute("beltRank").getValue(),
                    people.get(i).getAttribute("trainingRank").getValue(), schedules);
            }
        }
        return null;
    }
    
    /**
     * Changes a person's attributes. Only allows changing of beltRank and trainingRank. trainingRank can only be changed on trainers.
     * @param name The person we are changing's name
     * @param attribute The name of the attribute we are changing, can be "beltRank" or "trainingRank"
     * @param value The new String value of the attribute
     */
    public boolean setPersonAttr(String name, String attribute, String value) {
        boolean changed = false;
        if (!attribute.equals("beltRank") && !attribute.equals("trainingRank")) {
            return changed;
        }
        Elements people = _root.getChildElements("people");
        for (int i = 0; i < people.size(); i++) {
            if (people.get(i).getAttribute("name").getValue().equals(name)) {
                if ((attribute.equals("trainingRank")) && !(people.get(i).getAttribute("title").getValue().equals("Trainer"))) {
                    return changed;
                }
                people.get(i).getAttribute(attribute).setValue(value);
                if (peopleInstances.containsKey(name)) {
                    if (attribute.equals("beltRank")) {
                        peopleInstances.get(name).setBeltRank(People.BeltRank.getRank(value));
                    } else {
                        ((Trainer)peopleInstances.get(name)).setTrainingRank(People.BeltRank.getRank(value));
                    }
                }
                CurrentProject.save();
                return true;
            }
        }
        return false;
    }
    
    public People getPerson(int index) {
        Elements people = _root.getChildElements("people");
        for (int i = 0; i < people.size(); i++) {
            if (i == index) {
                if (peopleInstances.containsKey(people.get(i).getAttribute("name").getValue())) {
                    return peopleInstances.get(people.get(i).getAttribute("name").getValue());
                }
                ArrayList<String> schedules = new ArrayList<String>();
                for (int j = 0; j < people.get(i).getAttributeCount(); j++) {
                    Attribute attribute = people.get(i).getAttribute(j);
                    if (attribute.getLocalName().contains("schedule")) {
                        schedules.add(attribute.getValue());
                    }
                }
                return createPerson(people.get(i).getAttribute("title").getValue(),
                        people.get(i).getAttribute("name").getValue(),
                        people.get(i).getAttribute("beltRank").getValue(),
                        people.get(i).getAttribute("trainingRank").getValue(),
                        schedules);
            }
        }
        return null;
    }
    
    /**
     * Adds a person to the person list in _root.
     */
    public void addPerson(String title, String name, String beltRank, String trainingRank, List<String> schedules) {
        Element person = new Element("people");
        person.addAttribute(new Attribute("id", Util.generateId()));
        person.addAttribute(new Attribute("title", title));
        person.addAttribute(new Attribute("name", name));
        person.addAttribute(new Attribute("beltRank", beltRank));
        if (trainingRank != null) {
            person.addAttribute(new Attribute("trainingRank", trainingRank));
        }
        if (schedules != null) {
            for (int i = 0; i < schedules.size(); i++) {
                person.addAttribute(new Attribute("schedule" + i, schedules.get(i)));
            }
        }

        _root.appendChild(person);
        for (PeopleListNotificationListener listener : listeners) {
            listener.personAdded(getPerson(name));
        }
    }
    
    /**
     * Removes a person from the person list.
     */
    public boolean removePerson(String name) {
        boolean removed = false;
        Elements people = _root.getChildElements("people");
        People person = null;
        for (int i = 0; i < people.size(); i++)
            if (people.get(i).getAttribute("name").getValue().equals(name)) {
                person = getPerson(people.get(i).getAttribute("name").getValue());
                _root.removeChild(people.get(i));
                removed = true;
            }
        if (removed) {
            for (PeopleListNotificationListener listener : listeners) {
                listener.personRemoved(person);
            }
        }
        return removed;
    }

    public void addSchedule(People person, TrainerSchedule schedule) {
        if (schedule == null) {
            return;
        }
        Elements people = _root.getChildElements("people");
        for (int i = 0; i < people.size(); i++) {
            if (person.getName().equals(people.get(i).getAttribute("name").getValue())) {
                int j = 0;
                while (people.get(i).getAttribute("schedule" + j) != null) {
                    j++;
                }
                people.get(i).addAttribute(new Attribute("schedule" + j, schedule.toString()));
                break;
            }
        }
    }

    public void removeSchedule(People person, TrainerSchedule schedule) {
        Elements people = _root.getChildElements("people");
        for (int i = 0; i < people.size(); i++) {
            if (person.getName().equals(people.get(i).getAttribute("name").getValue())) {
                for (int j = 0; j < people.get(i).getAttributeCount(); j++) {
                    Attribute attribute = people.get(i).getAttribute(j);
                    if (attribute.getLocalName().contains("schedule")) {
                        if (attribute.getValue().equals(schedule.toString())) {
                            people.get(i).removeAttribute(attribute);
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Returns the count of people within the saved root folder.
     */
    public int getPeopleCount() {
        return _root.getChildElements("people").size();
    }
    
    public Document getXMLContent() {
        return _doc;
    }

    public void addListener(PeopleListNotificationListener listener) {
        listeners.add(listener);
    }

    public void removeListener(PeopleListNotificationListener listener) {
        listeners.remove(listener);
    }
}
