package main.java.memoranda;

import java.util.List;
import java.util.Vector;

import nu.xom.Document;

public interface PeopleList {
    
    Vector<People> getAllPeople();
    
    void printAllPeople();
    
    People createPerson(String title, String name, String beltRank, String trainingRank, List<String> schedule);
    
    boolean setPersonAttr(String name, String attribute, String title);
    
    People getPerson(String name);
    
    People getPerson(int index);
    
    void addPerson(String title, String name, String beltRank, String trainingRank, List<String> schedule);
    
    boolean removePerson(String name);

    void addSchedule(People person, TrainerSchedule schedule);

    void removeSchedule(People person, TrainerSchedule data);

    int getPeopleCount();
    
    Document getXMLContent();

    void addListener(PeopleListNotificationListener listener);

    void removeListener(PeopleListNotificationListener listener);
}
