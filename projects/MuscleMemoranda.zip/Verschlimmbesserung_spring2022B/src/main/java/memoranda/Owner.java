package main.java.memoranda;

import main.java.memoranda.People;

public class Owner extends People {
	
	public Owner(String name, BeltRank beltRank) {
		super(name, beltRank, Title.OWNER);
	}
	
}
