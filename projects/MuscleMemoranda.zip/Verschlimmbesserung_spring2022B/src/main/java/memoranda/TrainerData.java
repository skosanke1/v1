package main.java.memoranda;

import javax.swing.*;

public class TrainerData {
    public boolean empty;

    private Trainer trainer;
    private TrainerSchedule schedule;
    private JButton button;

    public TrainerData(Trainer trainer, TrainerSchedule schedule) {
        this.trainer = trainer;
        this.schedule = schedule;
        empty = false;
        button = new JButton("Schedule");
    }

    public TrainerData(Trainer trainer) {
        this.trainer = trainer;
        this.schedule = null;
        empty = true;
        button = new JButton("Schedule");
        button.setEnabled(false);
    }

    public Trainer getTrainer() {
        return trainer;
    }

    public TrainerSchedule getSchedule() {
        return schedule;
    }

    public JButton getButton() {
        return button;
    }
}