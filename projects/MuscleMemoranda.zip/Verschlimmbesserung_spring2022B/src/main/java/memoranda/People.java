package main.java.memoranda;

public class People {
	private String name;
	private BeltRank beltRank;
	protected Title title;
	
	/**
	 * Enum for title to increase usability in UI.
	 * @author halei
	 *
	 */
	public enum Title {
		STUDENT("Student"), TRAINER("Trainer"), OWNER("Owner");
		
		public final String name;
		
		private Title(String value) {
			this.name = value;
		}
		
		public String toString() {
		    return this.name;
		}
		
		/**
         * Method to return a Title based on its String name
         * @param name String name of Title
         * @return Title associated with String, or null if the name given is
         * not associated with a Title
         */
        public static Title getTitleName(String name) {
            for (Title t : Title.values()) {
                if (t.name.equals(name)) {
                    return t;
                }
            }
            return null;
        }
	}
	
	/**
	 * Enum for belt rank, ranks are given values based on their level.
	 * @author hconigli
	 */
	public enum BeltRank {
		
		WHITE(1, "White"), YELLOW(2, "Yellow"), ORANGE(3, "Orange"), PURPLE(4, "Purple"), BLUE(5, "Blue"),
		BLUESTRIPE(6, "Blue Stripe"), GREEN(7, "Green"), GREENSTRIPE(8, "Green Stripe"), BROWN1(9, "Brown 1"),
		BROWN2(10, "Brown 2"), BROWN3(11, "Brown 3"), BLACK1(12, "Black 1"), BLACK2(13, "Black 2"), BLACK3(14, "Black 3");
		
		public final int value;
		public final String name;
	
		private BeltRank(int value, String name) {
			this.value = value;
			this.name = name;
		}
		
		public String toString() {
		    return this.name;
		}
		
		/**
		 * Method to return a BeltRank based on its String name
		 * @param name String name of BeltRank
		 * @return BeltRank associated with String, or null if the name given is
		 * not associated with a BeltRank
		 */
		public static BeltRank getRank(String name) {
		    for (BeltRank br : BeltRank.values()) {
		        if (br.name.equals(name)) {
		            return br;
		        }
		    }
		    return null;
		}
		
		/**
         * Method to return a BeltRank based on its Integer value
         * @param value String name of BeltRank
         * @return BeltRank associated with value, or null if the value given is
         * not associated with a BeltRank
         */
        public static BeltRank getRank(int value) {
            for (BeltRank br : BeltRank.values()) {
                if (br.value == value) {
                    return br;
                }
            }
            return null;
        }
        
        /**
         * Compares two BeltRanks and returns an integer based on comparison result.
         * @param br BeltRank to compare this to
         * @return 1 if value of this is greater than br, -1 if this is less than br, 0 if 
         * this equals br
         */
        public int compareRank( BeltRank br) {
            if (this.value > br.value) {
                return 1;
            } else if (this.value < br.value) {
                return -1;
            } else {
                return 0;
            }
        }
	}
	
	/**
	 * Constructor for people, initializes name, title and beltRank.
	 * @param name Name of the person
	 * @param beltRank Belt rank of the person
	 * @param title Title of the person, can be student, owner, or trainer
	 */
	public People(String name, BeltRank beltRank, Title title) {
		this.name = name;
		this.beltRank = beltRank;
		this.title = title;
	}
	
	public String getName() {
		return name;
	}
	
	public BeltRank getBeltRank() {
		return beltRank;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setBeltRank(BeltRank rank) {
		this.beltRank = rank;
	}
	
	public Title getTitle() {
		return title;
	}
	
}
