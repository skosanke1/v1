/**
 * Event.java NOW USED AS THE CLASSES JAVA FILE FOR MUSCLE MEMORANDA
 * Created on 08.03.2003, Modified 4/10/2022
 * Package: net.sf.memoranda
 */
package main.java.memoranda;
import java.util.Date;

import main.java.memoranda.date.CalendarDate;


/*$Id: Event.java,v 1.4 2004/07/21 17:51:25 ivanrise Exp $*/
public interface Event {

    // @return whether the class is public or private
	String getType();
    // @return whether the instructor name
	String getInstructor();
    // @return the Room# as String eg "Room 1"
	String getRoom();
    String getId();
    // @return current number of students that signed up for class
    String getCurrentCapacity();

    //Returns String list of students, (separated by commas) that have booked the course
    String getStudentListRaw();
    
    //CalendarDate getDate();
    
    int getHour();
    
    int getMinute();
    
    //Date getTime();

    
	String getText();
    
    nu.xom.Element getContent();
    
    int getRepeat();
    
    CalendarDate getStartDate();
    CalendarDate getEndDate();
    int getPeriod();
    boolean isRepeatable();
    
    Date getTime();
    String getTimeString();
    
	boolean getWorkingDays();

    public int compareTo(Object o);
    
}
