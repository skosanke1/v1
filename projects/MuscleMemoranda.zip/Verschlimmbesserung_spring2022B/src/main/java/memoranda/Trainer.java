package main.java.memoranda;

import java.util.ArrayList;
import java.util.List;

public class Trainer extends People {
	BeltRank trainingRank;

	private List<TrainerSchedule> schedule = new ArrayList<>();
	
	public Trainer(String name, BeltRank beltRank, BeltRank trainingRank) {
		super(name, beltRank, Title.TRAINER);
		this.trainingRank = trainingRank;
	}
	
	public BeltRank getTrainingRank() {
		return trainingRank;
	}
	
	public void setTrainingRank(BeltRank trainingRank) {
		this.trainingRank = trainingRank;
	}


	public void addSchedule(TrainerSchedule schedule) {
		this.schedule.add(schedule);
	}

	public TrainerSchedule removeSchedule(TrainerSchedule schedule) {
		this.schedule.remove(schedule);
		return schedule;
	}

	public List<TrainerSchedule> getSchedule() {
		return schedule;
	}
}
