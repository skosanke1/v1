package test.java;

import static org.junit.Assert.*;

import main.java.memoranda.*;

import org.junit.Test;

public class RobertBlackBox {
    @Test
    public void testMakeSchedule() {
        TrainerSchedule schedule = new TrainerSchedule("Tim", "Mon May 02 00:08:40 MST 2022", "Mon May 02 00:10:40 MST 2022");
        assertEquals("Tim", schedule.getTrainerName());
        assertEquals("Mon May 02 00:08:40 MST 2022", schedule.getFromTime());
        assertEquals("Mon May 02 00:10:40 MST 2022", schedule.getToTime());
    }


    @Test
    public void testMakeScheduleFromString() {
        TrainerSchedule schedule = TrainerSchedule.fromString("Tim,Mon May 02 00:08:40 MST 2022,Mon May 02 00:10:40 MST 2022");
        assertEquals("Tim", schedule.getTrainerName());
        assertEquals("Mon May 02 00:08:40 MST 2022", schedule.getFromTime());
        assertEquals("Mon May 02 00:10:40 MST 2022", schedule.getToTime());
    }

    @Test
    public void testTrainerData() {
        Trainer trainer = new Trainer("Tim", People.BeltRank.BLUE, People.BeltRank.YELLOW);
        TrainerSchedule schedule = new TrainerSchedule(trainer.getName(),"Mon May 02 00:08:40 MST 2022", "Mon May 02 00:10:40 MST 2022");
        TrainerData trainerData = new TrainerData(trainer, schedule);
        assertEquals(trainer, trainerData.getTrainer());
        assertEquals(schedule, trainerData.getSchedule());
        assertEquals(false, trainerData.empty);
    }

    @Test
    public void testEmptyTrainerData() {
        Trainer trainer = new Trainer("Tim", People.BeltRank.BLUE, People.BeltRank.YELLOW);
        TrainerData trainerData = new TrainerData(trainer);
        assertEquals(trainer, trainerData.getTrainer());
        assertEquals(null, trainerData.getSchedule());
        assertEquals(true, trainerData.empty);
    }
}
