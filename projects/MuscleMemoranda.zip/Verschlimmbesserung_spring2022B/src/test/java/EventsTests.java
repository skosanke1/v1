package test.java;

import static main.java.memoranda.EventsManager.createEvent;
import static main.java.memoranda.EventsManager.removeEvent;
import static main.java.memoranda.date.CalendarDate.today;
import static org.junit.Assert.*;

import main.java.memoranda.*;
import main.java.memoranda.date.*;
import main.java.memoranda.util.CurrentStorage;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;


/*
A test class used to test the Event related java files
 */
public class EventsTests {
    Event testClass1;
    Event testClass2;
    Event testClass3;
    Event testClass4;
    Event testClass5;
    Event testClass6;
    Event testClass7;


    @org.junit.Before
    public void setUp(){
        testClass1 = createEvent( today() ,0 ,45 ,"Black Belt Training", "Private", "Room 1", "John Doe", "1", " ");
        testClass2 = createEvent( today() ,2 ,30 ,"White Belt Training", "Public", "Room 3", "Jane Smith", "20", " ");

        testClass4 = createEvent( today() ,5 ,30 ,"Black Belt Training", "Public", "Room 5", "Jane Smith", "20", " ");
        testClass5 = createEvent( today() ,5 ,30 ,"Black Belt Training", "Public", "Room 5", "Jane Smith", "20", " ");
        testClass6 = createEvent( today() ,6 ,30 ,"Black Belt Training", "Public", "Room 5", "Jane Smith", "20", " ");
        testClass7 = createEvent( today() ,5 ,40 ,"Black Belt Training", "Public", "Room 5", "Jane Smith", "20", " ");

    }

    @org.junit.After
    public void tearDown() {
    }

    //Tests the setters for classes
    @Test
    public void testCreateEvent() {
        testClass3 = createEvent( today() ,0 ,45 ,"Black Belt Training", "Private", "Room 1", "John Doe", "1", " ");
        assertEquals("Test failed: creating event", testClass3.getText(), "Black Belt Training");
    }

    //Tests the getters for classes
    @Test
    public void testGetRoom() {
        assertEquals("Test failed: return room number", testClass2.getRoom(), "Room 3");
    }

    //Tests the hour / minute values for classes
    @Test
    public void testClassLength() {
        assertEquals("Test failed: hour value for testClass 2", testClass2.getHour(), 2);
        assertEquals("Test failed: minute value for testClass 2", testClass2.getMinute(), 30);
    }

    //Useful in showing the instructor for a given class
    @Test
    public void getClassInstructor() {
        assertEquals("Test failed: return instructor name", testClass2.getInstructor(), "Jane Smith" );
    }

    //Class type - private or public
    @Test
    public void testGetType() {
        assertEquals("Test failed: return class type", testClass1.getType(), "Private" );
        assertEquals("Test failed: return class type", testClass2.getType(), "Public" );
    }

    //Viewing max capacity of a class.
    @Test
    public void testGetCurrentCapacity() throws Exception {

        assertEquals("Test failed: return class capacity", testClass1.getCurrentCapacity(), "1" );
        assertEquals("Test failed: return class capacity", testClass2.getCurrentCapacity(), "20" );
    }

    //Useful in verifying classes are scheduled at correct time.
    @Test
    public void testGetHour() throws Exception {
        int result = testClass1.getHour();
        Assert.assertEquals(0, result);
    }

    //Useful in verifying classes are scheduled at correct minute.
    @Test
    public void testGetMinute() throws Exception {
        int result = testClass1.getMinute();
        Assert.assertEquals(45, result);
    }

    //Useful in verifying classes are the same
    @Test
    public void testCompareTo() throws Exception {
        int result = testClass4.compareTo(testClass5);
        Assert.assertEquals("compare 2 events: ",0, result);
    }

    //Useful in verifying classes are not the same differing by the hour
    @Test
    public void testNotCompareToHour() throws Exception {
        int result = testClass5.compareTo(testClass6);
        Assert.assertNotEquals("compare 2 events that differ by hr:",0, result);
    }

    //Useful in verifying classes are not the same differing by the minute
    @Test
    public void testNotCompareToMinute() throws Exception {
        int result = testClass5.compareTo(testClass7);
        Assert.assertNotEquals("2 events differ by minute:", 0, result);
    }


    //Useful in verifying classes are not the same differing by the minute
    @Test
    public void testgetPeriod() throws Exception {
        int result = testClass5.getPeriod();
        Assert.assertEquals("period getter:", 0, result);
    }

}
