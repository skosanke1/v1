package test.java;

import static org.junit.Assert.*;

import main.java.memoranda.*;
import main.java.memoranda.ui.AgendaPanel;

import org.junit.Test;
import java.util.ArrayList;
import java.util.List;

public class HaleighBlackBox {
    
    PeopleList _people = CurrentProject.getPeopleList();
    Trainer trainer;
    Student student;
    Owner owner;
    int testableSize;
    String fromString;
    String toString;
    
    @org.junit.Before
    public void setUp() throws Exception {
        trainer = new Trainer("Scooby Doo", People.BeltRank.BLACK3, People.BeltRank.BLACK3);
        student = new Student("Shaggy Guy", People.BeltRank.WHITE);
        owner = new Owner("Fred Boy", People.BeltRank.BLUE);
        int beforeSize = _people.getAllPeople().size();
        testableSize = beforeSize + 3;
        _people.addPerson(trainer.getTitle().name, trainer.getName(), trainer.getBeltRank().name, trainer.getTrainingRank().name, new ArrayList<String>());
        _people.addPerson(student.getTitle().name, student.getName(), student.getBeltRank().name, "0", new ArrayList<String>());
        _people.addPerson(owner.getTitle().name, owner.getName(), owner.getBeltRank().name, "0", new ArrayList<String>());
        
    }
    
    @org.junit.After
    public void tearDown() {
        _people.removePerson("Scooby Doo");
        _people.removePerson("Shaggy Guy");
        _people.removePerson("Fred Boy");
    }
    
    // Tests that removePerson will correctly remove a person from the project's list.
    @Test
    public void testRemovePerson() {
        assertTrue("Person who should be on the list was not in the list", _people.removePerson("Shaggy Guy"));
        assertFalse("Person who was removed from the list was still on the list", _people.removePerson("Shaggy Guy"));
    }
    
    // This one is just for me to visualize what's happening
    @Test
    public void printPeople() {
        _people.printAllPeople();
    }
    
    // Tests that peopleCount returns the correct amount of people in the list.
    @Test
    public void testPeopleCount() {
        assertEquals("People count does not return correct amount of people", testableSize, _people.getPeopleCount());
    }

    // Tests that comparing belt ranks returns correct value for greater than, equal, and less than.
    @Test
    public void testBeltRankComparison() {
        assertEquals("Compare rank does not return correct number for rank less than", -1, student.getBeltRank().compareRank(trainer.getBeltRank()));
        assertEquals("Compare rank does not return correct number for rank greater than", 1, trainer.getBeltRank().compareRank(student.getBeltRank()));
        assertEquals("Compare rank does not return correct number for rank equals", 0, student.getBeltRank().compareRank(People.BeltRank.WHITE));
    }
    

    // Tests that getPeopleCount returns 0 when empty.
    @Test
    public void testPeopleCountEmpty() {
        _people.removePerson("Shaggy Guy");
        _people.removePerson("Scooby Doo");
        _people.removePerson("Fred Boy");
        assertEquals("People count does not return correct amount of people when empty", testableSize - 3, _people.getPeopleCount());
    }

    
    // Tests that getting a title with a string will return the correct title.
    @Test
    public void testTitleStringGetter() {
        assertEquals("Getting a title from a string does not return correct title enum", People.Title.TRAINER, People.Title.getTitleName("Trainer"));
    }
    
    //Tests setPersonAttr changes the value in the list of elements
    @Test
    public void testSetPersonAttr1() {
        _people.setPersonAttr("Shaggy Guy", "beltRank", "Black 3");
        assertEquals("Set person attribute does not set belt rank properly", "Black 3", _people.getPerson("Shaggy Guy").getBeltRank().toString());
    }
    
    @Test
    public void testSetPersonAttr2() {
        assertTrue("Setting training rank does not go through the correct path",_people.setPersonAttr("Scooby Doo", "trainingRank", "White"));
        assertEquals("Set person attribute does not set training rank properly", "White", ((Trainer)_people.getPerson("Scooby Doo")).getTrainingRank().toString());
    }
    
    @Test
    public void testSetPersonAttr3() {
        assertFalse("Set person attribute allows changing of trainingRank when person is not trainer", 
                _people.setPersonAttr("Fred Boy", "trainingRank", "Black 1"));
    }
    
    //Test logic of adding AM PM to agenda table schedule times.
    @Test
    public void testAMPM() {
        testAMPMHelper(8, 5);
        assertEquals("Does not logically assign AM and PM to start time.", ":00 AM", fromString);
        assertEquals("Does not logically assign AM and PM to end time.", ":00 PM", toString);
        testAMPMHelper(10, 11);
        assertEquals("Does not logically assign AM and PM to start time.", ":00 AM", fromString);
        assertEquals("Does not logically assign AM and PM to end time.", ":00 AM", toString);
    }
    
    @Test
    public void testAM() {
        testAMPMHelper(10, 11);
        assertEquals("Does not logically assign AM to start time.", ":00 AM", fromString);
        assertEquals("Does not logically assign AM to end time.", ":00 AM", toString);
    }
    
    @Test
    public void testPM() {
        testAMPMHelper(4, 5);
        assertEquals("Does not logically assign PM to start time.", ":00 PM", fromString);
        assertEquals("Does not logically assign PM to end time.", ":00 PM", toString);
    }
    
    // this is the exact function used in AgendaGenerator to determine AM or PM, but
    // it is not a method, so this is a helper to use it here. It operates on the idea that
    // the gym does not start new classes after 6 PM.
    public void testAMPMHelper(int from, int to) {
        if (from > to) {
            fromString = ":00 AM";
            toString = ":00 PM";
        } else if (from > 6) {
            fromString = ":00 AM";
            toString = ":00 AM";
        } else {
            fromString = ":00 PM";
            toString = ":00 PM";
        }
    }
    
}
