package test.java;

import static org.junit.Assert.*;

import main.java.memoranda.date.CalendarDate;
import main.java.memoranda.date.CurrentDate;
import main.java.memoranda.util.RandomWorkoutHelper;
import main.java.memoranda.util.Util;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import java.util.Arrays;
import java.util.Collection;

//@RunWith(Parameterized.class)
public class projectTest {


    /*
     @Test
    public void randomWorkoutTest() throws Exception {

        String n = RandomWorkoutHelper.getRandomWorkoutString(49);

        assertEquals("crunches","crunches",n);

    }
     */

/*
    @Test
    public void randomWorkoutTest2() throws Exception {

        String n = RandomWorkoutHelper.getRandomWorkoutString(55);

        assertEquals("run","run",n);

    }
 */

/*
    @Test
    public void randomWorkoutTest3() throws Exception {
        try {
            assertEquals("Exception", RandomWorkoutHelper.generateRandomNum(-60, -60));

        } catch (Exception e) {
            String message = "Error generating random number, it ended up being below 0. Try again.";
            assertEquals("Exception message", message, e.getMessage());
        }
    }

    @Test
    public void randomWorkoutTest4() throws Exception {
        try {
            assertEquals("Exception", RandomWorkoutHelper.generateRandomNum(600, 600));

        } catch (Exception e) {
            String message = "Error generating random number, too large for our bounds. Keep it under 100.";
            assertEquals("Exception message", message, e.getMessage());
        }
    }
    */
}
