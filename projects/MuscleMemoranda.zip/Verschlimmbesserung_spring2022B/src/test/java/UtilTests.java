package test.java;

import static org.junit.Assert.*;

import main.java.memoranda.date.CalendarDate;
import main.java.memoranda.date.CurrentDate;
import main.java.memoranda.util.Util;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import java.util.Arrays;
import java.util.Collection;

//@RunWith(Parameterized.class)
public class UtilTests {

    //very simple Blackbox test just to show that this works.
    @Test
    public void getDate1() throws Exception {
        CalendarDate expectedDate = CurrentDate.get();
        CalendarDate realDate = CurrentDate.get();
        assertEquals("success", expectedDate, realDate);
    }

    @Test
    public void millisFromHoursTest() throws Exception {
        long num1 = 0;
        long num2 = 0;

        num1 = Util.getMillisFromHours("5");
        num2 = Util.getMillisFromHours("5");
        assertEquals("success", num1, num2);
    }

    @Test
    public void hoursFromMillisTest() throws Exception {
        long num1 = 0;
        long num2 = 0;
        String ans1;
        String ans2;

        ans1 = Util.getHoursFromMillis(num1);
        ans2 = Util.getHoursFromMillis(num2);
        assertEquals("success", ans1, ans2);
    }

    @Test
    public void getCData() throws Exception {
        String ans1 = "test";
        String ans2 = "test";
        String final1;
        String final2;

        final1 = Util.getCDATA(ans1);
        final2 = Util.getCDATA(ans2);
        assertEquals("success", final1, final2);
    }

    @Test
    public void getWorkoutString() throws Exception {
        String ans1 = "test";
        ans1 = main.java.memoranda.util.RandomWorkoutHelper.getRandomWorkoutString(1);
        assertEquals("success", "Bicycle", ans1);
    }

    @Test
    public void getWorkoutString2() throws Exception {
        String ans1 = "test";
        ans1 = main.java.memoranda.util.RandomWorkoutHelper.getRandomWorkoutString(42);
        assertEquals("success", "Box", ans1);
    }

    @Test
    public void getRandomNum() throws Exception {
        int num1;
        int num2;

        num1 = main.java.memoranda.util.RandomWorkoutHelper.generateRandomNum(1,1000);
        num2 = main.java.memoranda.util.RandomWorkoutHelper.generateRandomNum(1,1000);
        assertNotEquals("success", num1, num2);
    }

    @Test
    public void getRandomNum2() throws Exception {
        int num1;
        int num2;

        num1 = main.java.memoranda.util.RandomWorkoutHelper.generateRandomNum(1,1000);
        num2 = main.java.memoranda.util.RandomWorkoutHelper.generateRandomNum(1,1000);
        assertNotEquals("success", num1, num2);
    }

}