package test.java;

import static org.junit.Assert.*;

import main.java.memoranda.date.CalendarDate;
import main.java.memoranda.date.CurrentDate;
import main.java.memoranda.util.Util;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import java.util.Arrays;
import java.util.Collection;




//@RunWith(Parameterized.class)
public class SepehrRandAndUtilTests{


    @Test
    public void nextRandomDiffTest1() throws Exception {
        int n1 = RandomWorkoutHelper.generateRandomNum(1, 100);
	int n2 = RandomWorkoutHelper.generateRandomNum(1, 100);
        assertEquals("fail", n1, n2);
    }

    @Test
    public void nextRandomDiffTest2() throws Exception {
        int n1 = RandomWorkoutHelper.generateRandomNum(1, 50);
	int n2 = RandomWorkoutHelper.generateRandomNum(1, 50);
	String randWorkout1 = RandomWorkoutHelper.getRandomWorkoutString(randomInteger);
	String randWorkout2 = RandomWorkoutHelper.getRandomWorkoutString(randomInteger);
        assertEquals("fail", randWorkout1, randWorkout2);
    }

    @Test
    public void millisFromHoursTest() throws Exception {
        long n1 = 0;
        long n2 = 0;
        n1 = Util.getMillisFromHours("1");
        n2 = Util.getMillisFromHours("2");
	n2 = num2/2;
        assertEquals("success", num1, num2);
    }

    @Test
    public void getCDataTest() throws Exception {
        String answer1 = "te*st#";
        String answer2 = "te#st*";
        String final1;
        String final2;
        final1 = Util.getCDATA(answer1);
        final2 = Util.getCDATA(answer2);
        assertEquals("success", final1, final2);
    }

}