### Quality Policy
> Describe your Quality Policy in detail for this Sprint (remember what I ask you to do when I talk about the "In your Project" part in the lectures and what is mentioned after each assignment (in due course you will need to fill out all of them, check which ones are needed for each Deliverable). You should keep adding things to this file and adjusting your policy as you go.
> Check in Project: Module Concepts document on Canvas in the Project module for more details 

**GitHub Workflow** (start Sprint 1)
  > Currently, we are planning to make a branch for each task we are accomplishing. Each individual will have a branch that they will be able to test on, as well as a branch per story. Once tested on the individual's local machine, they will then merge it to the dev branch. This will act as our "staging" environment. Once these features are tested on dev, we will then merge to the master brnahc and begin testing to ensure compatibility. 

**Unit Tests Blackbox** (start Sprint 2)
  > Testing any new public method that we create within the program. 
  > Like to test any new method that multiple developers use. (e.g. helper methods)
  > Any new method that was previously failing (e.g. bugs) add it to unit tests. 
  > Test any .class files. 
  > Test a new method added by another team member. (Must request testing in the commit message)

 **Unit Tests Whitebox** (online: start Sprint 2, campus: start Sprint 3)
  > Anytime we need to test storing data/new functionality. 
  > Like to test any new method that multiple developers use. (e.g. helper methods)
  > Any new method with multiple return values (e.g. switch statement), make sure every branch is tested.

**Code Review** (online: due start Sprint 2, campus: start Sprint 3)
  > Should do code reviewing before merging to dev (keep it on testing tab, on the user story branch, and request the code review on slack).
  > Each user story will have will be reviewed by another member, and then merged.    

  **Include a checklist/questions list which every developer will need to fill out/answe when creating a Pull Request to the Dev branch.**
  - [ ] My code compiles
  - [ ] My code has been developer-tested and includes unit tests
  - [ ] My code includes javadoc where appropriate
  - [ ] My code is tidy (indentation, line length, no commented-out code, no spelling mistakes, etc)
  - [ ] I have considered proper use of exceptions
  - [ ] I have made appropriate use of logging
  - [ ] I have eliminated unused imports
  - [ ] I have eliminated Eclipse warnings
  - [ ] I have considered possible NPEs (Null Pointer Exceptions)
  - [ ] The code follows the Coding Standards
  - [ ] Are there any leftover stubs or test routines in the code? Comments are comprehensible and add something to the maintainability of the code (trivial comments do not help, rather write readable code)
 
 **Include a checklist/question list which every reviewer will need to fill out/anser when conducting a review, this checklist (and the answers of course) need to be put into the Pull Request review.**
  - [ ] Comments are neither too numerous nor verbose
  - [ ] Types have been generalized where possible
  - [ ] Parameterized types have been used appropriately
  - [ ] Exceptions have been used appropriately
  - [ ] Repetitive code has been factored out
  - [ ] Frameworks have been used appropriately – methods have all been defined appropriately
  - [ ] Command classes have been designed to undertake one task only
  - [ ] JSPs do not contain business logic
  - [ ] Unit tests are present and correct
  - [ ] Common errors have been checked for
  - [ ] Potential threading issues have been eliminated where possible

**Static Analysis**  (online: start Sprint 3, campus: start Sprint 3)
  > We will focus on functionality bugs. Before every pull into dev or master, look at the bug report, to make sure the code we add does not have bugs in it.
