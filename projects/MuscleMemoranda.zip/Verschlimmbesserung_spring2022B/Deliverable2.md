1: Basic Information (needed before you start with your Sprint -- Sprint Planning)
Topic you chose: Gym Management System

Sprint Number: 2

Scrum Master: Sepehr

Git Master: Haleigh

Sprint Planning (For Sprint 1-3)
Sprint Goal: We'll be focusing mostly on implementing more of the back-end functionality for Muscle Memoranda and update more of the components that are currently outdated. We will also be focusing on writing Unit Tests for this sprint to ensure that our code is efficient/accurate. By doing this, we'll set ourselves up for Sprint 3 to focus on design changes and have a stronger product through testing.

How many User Stories did you add to the Product Backlog: 8

How many User Stories did you add to this Sprint: 12

Answer the questions below about your Sprint Planning?

Why did you add these US, why do you think you can get them done in the next Sprint?

The Unit Testing User Stories were vital to get the team setup with the capabilities to use JUnit tests for their own codework. On top of the testing stories, we made sure to add stories focused on enhancing each view/page within the program from a functional perspective. This will make the program more sturdy overall and make more sense from a consumer perspective. We believe can get them completed because it's the next logical step in enhancing our program.

Why do you think these fit well with your Sprint goal? (details)

These will fit well with our sprint goal because it will set us up for Sprint 3. During Sprint 3, making large functional changes to the program may cause more merge conflicts/bugs than we would like. It makes more sense to go through this early on in development so that we can focus more on the details during the final sprint. 

Do you have a rough idea what you need to do? (if the answer is no then please let me know on Slack)

Yes

2: During the Sprint
Fill out the Meeting minutes during your Sprint and keep track of things. Update your Quality policies when needed, as explained in the lectures and in the Quality Policy documents on Canvas. I would also advise you to already fill out the Contributions section (End of sprint) as you go, to create less work at the end.

3: After the Sprint
Sprint Review
Answer as a team!

Screen Cast link: https://asu.zoom.us/rec/share/oTs4TtbAalaQHzrV08HcEWky2I6g58uPA0MSEt_yKDupFWvRKXhplLLPE6Oy7T2U.2s8B8VGdmkfI7ydU?startTime=1650437172000
Passcode: 1J+K3a@E

Answer the following questions as a team.

What do you think is the value you created this Sprint? 
We added a lot of functionality to the program, which made it more suitable as a gym scheduling tool. 

Do you think you worked enough and that you did what was expected of you? 
Yes, we were able to complete Almost all of the user stories, and every team member completed their assigned tasks. Last sprint we understimated the user stories, which led to completing our user stories later this Sprint, and it proved to be much more challenging in the testing phase. 

Would you say you met the customers’ expectations? Why, why not? 
Yes, we met most of the expectations by working on every user story and writing 500+ LOC. 

Sprint Retrospective
Did you meet your sprint goal?
Yes, we successfuly completed the goals we set at the beginning of the Sprint. 

Did you complete all stories on your Spring Backlog? 
Yes, except for one task on US69. 

Did you work at a consistent rate of speed, or velocity? (Meaning did you work during the whole Sprint or did you start working when the deadline approached.)
Yes, there was a consistent, homogenous team work as certain tasks depended on completion of other tasks. 

Did you deliver business value?
Yes, we got all the functionality down, which paves the way for putting them together in Sprint 3. 

Did you follow the Scrum process (e.g. move Tasks correctly?, keep the Taiga board up to date? work consistently?)
Yes, we followed the process and checked Taiga regularly to ensure it is up to date. 

Are there things the team thinks it can do better in the next Sprint? (not needed for last Sprint)
Being more confident about our moving from the 'ready to test' to 'completed' stage fast enough. 

How do you feel at this point? Get a pulse on the optimism of the team.
We are confident in our product's funcitionality at the moment and believe we will finish Sprint 3 successfully. 

Contributions:
In this section I want you to point me to your main contributions (each of you individually) for the current Sprint. Some of the below you will only need starting in later Sprints, I marked when they become important.

Copy the section for each team member and then everyone adds their individual contributions.

Team member Jace -- :
**Do you think you individually worked consistently and put in enough work into the project (give a short answer).

Yes, I believe my contributions to JUnit testing as well as the "Random Workout Generator" contributed greatly to the team.

**Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :

-https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/8ff4e1d48327eb6a80f83ecd754db00e9207a511  (Adding JUnit 4 to the proj)
-https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/41deb7bc5656c6021cad319f5f26debff60ef6fe  (Writing Unit Tests)
-https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/1428cc34b243768ff08f1fab3863f9165a14503c  (Adding random workout generator backend functionality)

#### Team member **STEVEN**:

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer). **
I believe that I worked consistently both weeks this sprint and got both functionality and UI changed completed this sprint, and was able to successfully complete two User Stories this time.

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :**


    - [Commit 1] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/474d2e4914add5462ea32754a0f4e15213e130e5) - Add details on classes table
    - [Commit 2] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/8a2260de47d75f3a276b551818fb5b3465771f0f) - Add attributes to 'new class'
    - [Commit 3] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/5a67f7492cee4e99d2d4b9b0284dd75ba6fcdcf3) - Create new getter / setter methods
    - [Commit 4] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/7bd745ac12a20454b5c874d2e8d9d4a8d12a17fd) - Change fonts to serif everywhere
    - [Commit 5] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/4bdc34beeb2f120a138c7a9ca8c678ce3def47d7) - Create Unit Tests for Classes
 
 **GitHub links to your Pull Requests (up to 3 links) -- fill out starting Sprint 1:**

    - [Pull Request 1](https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/12) - US67-font-changes
    - [Pull Request 2](https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/17) - US63-classes
  
Team member Haleigh -- :
**Do you think you individually worked consistently and put in enough work into the project (give a short answer).
Yes, I put in a lot of hours this week and completed one very difficult User Story and nearly completed another difficult one. I did the unit tests and worked consistently from the first day, although I did not move anything to closed until much later since they all took so long.
Below I want links that I can click on to your commit or PullRequest with your work (not the branch you worked on). I also want a short description what this commit/PR is about (or test etc.)

Example: Commit 1 - Updated DeliverableX.md table to include who did not attend meetings

**Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :

- https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/7e3a254115a2c66061b65a5390836c76f420596b - Created PeopleListImpl class for the objects in PeopleTable
- https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/dd47fe5a29b451709556a5c7145b7cb2b62ac006 - Changed dialogue box for adding a person to the table to ask for correct arguments
- https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/e88cc996b5b52b4ec1af64e28ff69c2131525788 - Created a save button for notes page
- https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/8542e0d0fcf296e4a4e926d98585d35ea8636a80 - Redid the NotesControlPanel methods to allow the additional functionality
- https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/a85da2075d633a80578a31260123594cc81a301d - Add unit tests
**GitHub links to your Pull Requests (up to 3 links) -- fill out starting Sprint 1:

- https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/11 - People Page
- https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/13 - Enhance Notes
- https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/19 - Unit Tests


Team member Robert -- : **Do you think you individually worked consistently and put in enough work into the project (give a short answer).
I do. My portion of the project involved substantial changes and additions to the codebase. It tooks time before I was able to move the tasks over to completed because much of my user stories required work from other user stories already assigned to other members. However, I was able to get my stories to a place where all I needed was access to others and it would be completed. I do believe that I still have much work to do on the user experience of the project, but that is something I will resolve in Sprint 3.

**Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :

https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/tree/US61-training-page Functionality for the training page

https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/tree/US54-unit-tests Unit tests


Team member STEVEN -- :
**Do you think you individually worked consistently and put in enough work into the project (give a short answer). I believe that I worked consistently this Sprint and put enough work into this project. I committed multiple times each week and tasks within multiple User Stories.

**Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :

d35189824eff96fca8a3e4c5247e0a43483ade10) - Change app version, build names

#### Team member **Sepehr**:

  **Do you think you individually worked consistently and put in enough work into the project (give a short answer). **
In addition to performing the duties of the Scrum Master in ensuring the Scrum process is followed and meetings are held, I also followed up with individual team members when needed and made sure everyone is doing good. I also spent 10+ hours on changing the colors and writing unit tests. 

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :**


    - [Commit 1] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/9720cfd2fe6f47c79ae4d10dc8a2cf316a4be373) - Update Quality Policy
    - [Commit 2] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/c1a13874cf5f467f73a135cd4258e2392b949592) - Add Unit Tests
    - [Commit 3] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/f38ec53ebf9b883cae7feeb4ffe5163af6e0392a) - Change foreground/icons to red
 
 **GitHub links to your Pull Requests (up to 3 links) -- fill out starting Sprint 1:**

    - [Pull Request 1] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/6) - Update Deliverables and Quality Policy
    - [Pull Request 2] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/21) - US45-unit-tests
    - [Pull Request 3] (https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/22) - US21-ui-color
    
   
   #### Team member Igor:
  **Do you think you individually worked consistently and put in enough work into the project (give a short answer). **
Yes, I do believe I did work consistently. I put in the hours, if not more into the project and commited regularly. I feel like it took me a bit to understand where some of the code goes or what does what, so that took a little bit of time, but I ran static analysis and implemented a version number as well as unit tests. I also added github actions.

  **Links to GitHub commits (not PR) with main code contribution (up to 5 links) - important in each :**

  https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/324096e08b2d705c393edeaf88056b3be2db679d -add unit testing

 https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/3830fce64c105897c14fe650cf73747f824f141a - fix performance bugs
 https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/c9e9107fed941f314ce87fd6e7a3819f439547b5 -add version number
 https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/commit/2571f9f08bbf42aa9ca523a37cfe493f4a755a6a - add spotbugs
 
 **GitHub links to your Pull Requests (up to 3 links) -- fill out starting Sprint 1:**
 https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/28 -  US93 to dev
 https://github.com/amehlhase316/Verschlimmbesserung_spring2022B/pull/9 - add action to github, CI.
 


## Below is just for you as a little reminder on what needs to be done
### Checklist for you to see if you are done with the current Sprint
- [X] Form above is complete
- [X] Your newest software is on the master branch on GitHub, it is tested and compiles/runs
- [X] This document is in your master branch on GitHub
- [X] Read the kickoff again to make sure you have all the details that I want
- [X] User Stories that were not completed, were left in the Sprint and a copy created to move to the next Sprint
- [X] Your Quality Policies are accurate and up to date
- [X] **Individual** Survey was submitted **individually** (create checkboxes below -- see Canvas to get link)
  - [X] JACE
  - [X] ROBERT
  - [x] HALEIGH
  - [X] SEPEHR
  - [X] STEVEN
  - [X] IGOR

#### For the next Sprint
  - [X] The original of this file was copied for the next Sprint (needed for all but last Sprint where you do not need to copy it anymore)
    - [X] Basic information (part 1) for next Sprint was included in this new Deliverable document 
  - [X] You added new User Stories to your Product Backlog, they are correctly written (needed after Sprint 1, 2)
  - [X] All User Stories have acceptance tests
  - [X] User Stories in your new Sprint Backlog have initial tasks which are in New column
  - [X] You know how to proceed (if not please reach out)
